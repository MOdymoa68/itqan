import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, Printer } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { averageItqan, countByKind, sessionItqan } from "@/lib/itqan";
import { downloadWeeklyPng, repeatedWords, weekSessions } from "@/lib/report";
import { useActiveProfile, useProfileSessions } from "@/lib/store";
import { rangeLabel } from "@/lib/surahs";
import { APP_NAME, CIRCLE_NAME, ERROR_LABEL, SESSION_LABEL } from "@/lib/types";
import {
  addDays,
  formatArDate,
  startOfWeekSunday,
  STUDY_DAYS,
  todayISO,
  WEEKDAYS_AR,
} from "@/lib/utils";

export const Route = createFileRoute("/report")({ component: ReportPage });

function ReportPage() {
  const profile = useActiveProfile();
  const sessions = useProfileSessions(profile?.id ?? null);
  const [busy, setBusy] = useState(false);
  const weekStart = startOfWeekSunday();
  const week = weekSessions(sessions, weekStart);
  const counts = countByKind(week.flatMap((s) => s.errors));
  const avg = averageItqan(week);
  const weak = repeatedWords(week, 2).slice(0, 8);

  async function saveImage() {
    if (!profile) return;
    setBusy(true);
    try {
      await downloadWeeklyPng(profile, sessions);
      toast.success("حُفظت صورة التقرير");
    } catch {
      toast.error("تعذر إنشاء الصورة");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="text-2xl font-semibold">تقرير الإنجاز</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          ملخص الأسبوع للمعلم أو للحفظ الشخصي. يمكن حفظه صورة أو طباعته PDF.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button onClick={() => void saveImage()} disabled={busy || !profile}>
          <Download className="size-4" />
          حفظ صورة
        </Button>
        <Button variant="outline" onClick={() => window.print()}>
          <Printer className="size-4" />
          طباعة / PDF
        </Button>
      </div>

      <Card className="print:border-0 print:shadow-none">
        <CardContent className="grid gap-5 py-6">
          <header className="border-b border-border pb-4">
            <p className="font-display text-3xl text-primary">{APP_NAME}</p>
            <p className="text-sm text-muted-foreground">{CIRCLE_NAME}</p>
            <p className="mt-2 text-sm font-medium">{profile?.name}</p>
            <p className="text-xs text-muted-foreground">
              {formatArDate(todayISO(weekStart))} — {formatArDate(todayISO(addDays(weekStart, 4)))}
            </p>
          </header>

          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {[
              ["الإتقان", avg == null ? "—" : `${avg}%`],
              ["الجلسات", String(week.length)],
              [ERROR_LABEL.stop, String(counts.stop)],
              [ERROR_LABEL.lahn, String(counts.lahn)],
              [ERROR_LABEL.note, String(counts.note)],
            ].map(([label, value]) => (
              <div key={label} className="rounded-xl bg-muted/70 px-3 py-3 text-center">
                <p className="font-display text-2xl tabular-nums text-primary">{value}</p>
                <p className="mt-1 text-xs text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>

          <section className="grid gap-2">
            <h2 className="text-sm font-semibold">الأيام الدراسية</h2>
            {STUDY_DAYS.map((d) => {
              const iso = todayISO(addDays(weekStart, d));
              const list = week.filter((s) => s.date === iso);
              return (
                <div key={d} className="flex items-start justify-between gap-3 rounded-lg bg-muted/50 px-3 py-2">
                  <span className="text-sm font-medium">{WEEKDAYS_AR[d]}</span>
                  <span className="text-left text-sm text-muted-foreground">
                    {list.length === 0
                      ? "لم يُسمَّع"
                      : list
                          .map(
                            (s) =>
                              `${SESSION_LABEL[s.type]} · ${rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)} · ${sessionItqan(s)}%`,
                          )
                          .join(" · ")}
                  </span>
                </div>
              );
            })}
          </section>

          <section className="grid gap-2">
            <h2 className="text-sm font-semibold">كلمات متكررة هذا الأسبوع</h2>
            {weak.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا تكرار يُذكر.</p>
            ) : (
              weak.map((w) => (
                <div key={w.word} className="flex items-center justify-between">
                  <span className="font-display text-xl">{w.word}</span>
                  <Badge variant="stop">{w.count}×</Badge>
                </div>
              ))
            )}
          </section>
        </CardContent>
      </Card>
    </div>
  );
}
