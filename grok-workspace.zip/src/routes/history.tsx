import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronDown, FileDown, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { countByKind, sessionItqan } from "@/lib/itqan";
import { useActiveProfile, useItqanStore, useProfileSessions } from "@/lib/store";
import { rangeLabel, SURAH_BY_ID } from "@/lib/surahs";
import { ERROR_LABEL, SESSION_LABEL } from "@/lib/types";
import { cn, formatArDate } from "@/lib/utils";

export const Route = createFileRoute("/history")({ component: HistoryPage });

function HistoryPage() {
  const profile = useActiveProfile();
  const sessions = useProfileSessions(profile?.id ?? null);
  const deleteSession = useItqanStore((s) => s.deleteSession);
  const [openId, setOpenId] = useState<string | null>(null);

  const grouped = useMemo(() => {
    const map = new Map<string, typeof sessions>();
    for (const s of sessions) {
      const list = map.get(s.date) ?? [];
      list.push(s);
      map.set(s.date, list);
    }
    return [...map.entries()];
  }, [sessions]);

  return (
    <div className="grid gap-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">السجل</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            كل جلسة تسميع، أخطاؤها، ونسبة الإتقان.
          </p>
        </div>
        <Button asChild variant="outline" size="sm">
          <Link to="/report">
            <FileDown className="size-4" />
            تقرير
          </Link>
        </Button>
      </div>

      {grouped.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            السجل فارغ حتى تُنهي أول تسميع.
          </CardContent>
        </Card>
      ) : (
        grouped.map(([date, list]) => (
          <section key={date} className="grid gap-2">
            <h2 className="text-sm font-medium text-muted-foreground">{formatArDate(date)}</h2>
            {list.map((s) => {
              const counts = countByKind(s.errors);
              const open = openId === s.id;
              return (
                <Card key={s.id} className="rounded-xl">
                  <CardContent className="py-3">
                    <button
                      type="button"
                      className="flex w-full items-center gap-3 text-right"
                      onClick={() => setOpenId(open ? null : s.id)}
                    >
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-semibold">
                          {SESSION_LABEL[s.type]} ·{" "}
                          {rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)}
                        </span>
                        <span className="mt-1 flex flex-wrap gap-1">
                          <Badge variant="stop">{counts.stop} أخطاء</Badge>
                          <Badge variant="lahn">{counts.lahn} لحون</Badge>
                          <Badge variant="note">{counts.note} تنبيهات</Badge>
                        </span>
                      </span>
                      <span className="font-display text-2xl text-primary tabular-nums">
                        {sessionItqan(s)}%
                      </span>
                      <ChevronDown
                        className={cn(
                          "size-4 text-muted-foreground transition-transform",
                          open && "rotate-180",
                        )}
                      />
                    </button>
                    {open ? (
                      <div className="mt-3 grid gap-2 border-t border-border pt-3">
                        {s.errors.length === 0 ? (
                          <p className="text-sm text-muted-foreground">جلسة بلا أخطاء مسجّلة.</p>
                        ) : (
                          s.errors.map((e) => (
                            <div key={e.id} className="rounded-lg bg-muted/70 px-3 py-2">
                              <div className="flex items-center gap-2">
                                <Badge variant={e.kind}>{ERROR_LABEL[e.kind]}</Badge>
                                <span className="font-display text-lg">
                                  {e.matchedWord || e.word || "—"}
                                </span>
                              </div>
                              {e.ayahText ? (
                                <p className="mt-1 font-display text-base leading-loose">
                                  {e.ayahText}
                                </p>
                              ) : null}
                              {e.ayahNumber ? (
                                <p className="text-xs text-muted-foreground">
                                  {SURAH_BY_ID[e.surahId ?? 0]?.name} · آية {e.ayahNumber}
                                </p>
                              ) : null}
                            </div>
                          ))
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="justify-start text-destructive"
                          onClick={() => deleteSession(s.id)}
                        >
                          <Trash2 className="size-4" />
                          حذف الجلسة
                        </Button>
                      </div>
                    ) : null}
                  </CardContent>
                </Card>
              );
            })}
          </section>
        ))
      )}
    </div>
  );
}
