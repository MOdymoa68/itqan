import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, BookMarked, Link2, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { averageItqan, countByKind, sessionItqan } from "@/lib/itqan";
import { useActiveProfile, useItqanStore, useProfileSessions } from "@/lib/store";
import { rangeLabel } from "@/lib/surahs";
import { ERROR_LABEL, SESSION_LABEL } from "@/lib/types";
import {
  addDays,
  formatArDate,
  formatHijri,
  startOfWeekSunday,
  STUDY_DAYS,
  todayISO,
  WEEKDAYS_AR,
} from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const profile = useActiveProfile();
  const sessions = useProfileSessions(profile?.id ?? null);
  const schedule = useItqanStore((s) =>
    profile ? s.schedules[profile.id] : undefined,
  );
  const completions = useItqanStore((s) =>
    profile ? s.completions[profile.id] : undefined,
  );

  const today = new Date();
  const dow = today.getDay();
  const iso = todayISO(today);
  const plan = schedule?.days[dow] ?? null;
  const doneToday = Boolean(completions?.[iso]);
  const weekStart = startOfWeekSunday(today);
  const weekSessions = sessions.filter((s) => {
    const start = todayISO(weekStart);
    const end = todayISO(addDays(weekStart, 6));
    return s.date >= start && s.date <= end;
  });
  const weekItqan = averageItqan(weekSessions);
  const weekCounts = countByKind(weekSessions.flatMap((s) => s.errors));
  const recent = sessions.slice(0, 4);
  const studyDone = STUDY_DAYS.filter((d) => {
    const date = todayISO(addDays(weekStart, d));
    return Boolean(completions?.[date]);
  }).length;

  return (
    <div className="grid gap-5">
      <section>
        <p className="text-sm text-muted-foreground">{formatHijri(today)}</p>
        <h1 className="mt-1 text-2xl font-semibold">سلامًا {profile?.name}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {formatArDate(iso)} · {WEEKDAYS_AR[dow]}
        </p>
      </section>

      <Card>
        <CardContent className="grid gap-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-medium text-muted-foreground">مقرر اليوم</p>
              {dow > 4 ? (
                <p className="mt-1 text-base font-medium">راحة نهاية الأسبوع</p>
              ) : plan ? (
                <p className="mt-1 text-base font-medium">
                  {rangeLabel(plan.fromSurah, plan.toSurah, plan.fromAyah, plan.toAyah)}
                </p>
              ) : (
                <p className="mt-1 text-base font-medium">لم يُحدد مقدار بعد</p>
              )}
            </div>
            <Badge variant={doneToday ? "default" : "outline"}>
              {doneToday ? "تم التسميع" : "بالانتظار"}
            </Badge>
          </div>
          <div className="flex gap-2">
            <Button asChild className="flex-1">
              <Link to="/recite/$type" params={{ type: "hifz" }}>
                ابدأ التسميع
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/schedule">الجدول</Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card>
          <CardContent>
            <p className="text-xs font-medium text-muted-foreground">إتقان الأسبوع</p>
            <p className="mt-1 font-display text-4xl text-primary tabular-nums">
              {weekItqan == null ? "—" : `${weekItqan}%`}
            </p>
            <Progress className="mt-3" value={weekItqan ?? 0} />
            <p className="mt-2 text-xs text-muted-foreground">{studyDone} من 5 أيام دراسية</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="grid gap-2">
            <p className="text-xs font-medium text-muted-foreground">أخطاء الأسبوع</p>
            {(
              [
                ["stop", weekCounts.stop],
                ["lahn", weekCounts.lahn],
                ["note", weekCounts.note],
              ] as const
            ).map(([k, n]) => (
              <div key={k} className="flex items-center justify-between text-sm">
                <span>{ERROR_LABEL[k]}</span>
                <span className="tabular-nums font-medium">{n}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <section className="grid gap-2">
        <h2 className="text-sm font-semibold">أقسام التسميع</h2>
        <div className="grid gap-2">
          <TypeCard
            type="hifz"
            icon={BookMarked}
            title="حفظ جديد"
            hint="سورة مقررة واحدة، مع تصحيح الكلمة حسب المصحف"
          />
          <TypeCard
            type="rabt"
            icon={Link2}
            title="ربط"
            hint="مدى من سورة إلى سورة أثناء الربط"
          />
          <TypeCard
            type="murajaa"
            icon={RefreshCw}
            title="مراجعة"
            hint="نفس آلية الربط لمواضع المراجعة"
          />
        </div>
      </section>

      <section className="grid gap-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold">آخر الجلسات</h2>
          <Link to="/history" className="text-xs font-medium text-primary">
            السجل كامل
          </Link>
        </div>
        {recent.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-sm text-muted-foreground">
              لا جلسات بعد. ابدأ تسميعًا من الأزرار أعلاه.
            </CardContent>
          </Card>
        ) : (
          <ul className="grid gap-2">
            {recent.map((s) => (
              <li key={s.id}>
                <Card className="rounded-xl">
                  <CardContent className="flex items-center justify-between gap-3 py-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium">
                        {SESSION_LABEL[s.type]} ·{" "}
                        {rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)}
                      </p>
                      <p className="text-xs text-muted-foreground">{formatArDate(s.date)}</p>
                    </div>
                    <span className="font-display text-2xl text-primary tabular-nums">
                      {sessionItqan(s)}%
                    </span>
                  </CardContent>
                </Card>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function TypeCard({
  type,
  icon: Icon,
  title,
  hint,
}: {
  type: "hifz" | "rabt" | "murajaa";
  icon: typeof BookMarked;
  title: string;
  hint: string;
}) {
  return (
    <Link to="/recite/$type" params={{ type }}>
      <Card className="rounded-xl transition-colors hover:bg-muted/60">
        <CardContent className="flex items-center gap-3 py-3">
          <span className="flex size-11 items-center justify-center rounded-lg bg-secondary text-primary">
            <Icon className="size-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-sm font-semibold">{title}</span>
            <span className="block text-xs text-muted-foreground">{hint}</span>
          </span>
          <ArrowLeft className="size-4 text-muted-foreground" />
        </CardContent>
      </Card>
    </Link>
  );
}
