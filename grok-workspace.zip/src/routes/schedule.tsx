import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { SurahPicker } from "@/components/surah-picker";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { clampAyah, useActiveProfile, useItqanStore } from "@/lib/store";
import { rangeLabel, SURAH_BY_ID } from "@/lib/surahs";
import type { DayPlan } from "@/lib/types";
import {
  addDays,
  startOfWeekSunday,
  STUDY_DAYS,
  todayISO,
  WEEKDAYS_AR,
  cn,
} from "@/lib/utils";

export const Route = createFileRoute("/schedule")({ component: SchedulePage });

function emptyPlan(): DayPlan {
  return { fromSurah: 1, toSurah: 1, fromAyah: 1, toAyah: 7 };
}

function SchedulePage() {
  const profile = useActiveProfile();
  const schedule = useItqanStore((s) =>
    profile ? s.schedules[profile.id] : undefined,
  );
  const completions = useItqanStore((s) =>
    profile ? s.completions[profile.id] : undefined,
  );
  const setDayPlan = useItqanStore((s) => s.setDayPlan);
  const toggleCompletion = useItqanStore((s) => s.toggleCompletion);
  const [editing, setEditing] = useState<number | null>(null);
  const [draft, setDraft] = useState<DayPlan>(emptyPlan());

  if (!profile) return null;

  const weekStart = startOfWeekSunday();
  const todayDow = new Date().getDay();

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="text-2xl font-semibold">الجدول الأسبوعي</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          نظّم مقدار التسميع من الأحد إلى الخميس. الجمعة والسبت للراحة.
        </p>
      </div>

      <div className="grid gap-2">
        {STUDY_DAYS.map((day) => {
          const date = addDays(weekStart, day);
          const iso = todayISO(date);
          const plan = schedule?.days[day] ?? null;
          const done = Boolean(completions?.[iso]);
          const isToday = todayDow === day;
          return (
            <Card
              key={day}
              className={cn("rounded-xl", isToday && "border-primary/40")}
            >
              <CardContent className="grid gap-3 py-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold">
                      {WEEKDAYS_AR[day]}
                      {isToday ? " · اليوم" : ""}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {plan
                        ? rangeLabel(plan.fromSurah, plan.toSurah, plan.fromAyah, plan.toAyah)
                        : "بدون مقدار"}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      type="button"
                      size="icon"
                      variant={done ? "default" : "outline"}
                      className="size-10"
                      onClick={() => toggleCompletion(profile.id, iso)}
                      aria-label={done ? "إلغاء الإنجاز" : "تعليم كمنجز"}
                    >
                      <Check className="size-4" />
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditing(day);
                        setDraft(plan ?? emptyPlan());
                      }}
                    >
                      تعديل
                    </Button>
                  </div>
                </div>

                {editing === day ? (
                  <div className="grid gap-3 rounded-xl bg-muted/70 p-3">
                    <div className="grid gap-3 sm:grid-cols-2">
                      <SurahPicker
                        label="من سورة"
                        value={draft.fromSurah}
                        onChange={(id) => {
                          const s = SURAH_BY_ID[id];
                          setDraft((d) => ({
                            ...d,
                            fromSurah: id,
                            fromAyah: 1,
                            toSurah: d.toSurah < id ? id : d.toSurah,
                            toAyah: s?.ayahs ?? d.toAyah,
                          }));
                        }}
                      />
                      <SurahPicker
                        label="إلى سورة"
                        value={draft.toSurah}
                        onChange={(id) => {
                          const s = SURAH_BY_ID[id];
                          setDraft((d) => ({
                            ...d,
                            toSurah: id,
                            toAyah: s?.ayahs ?? 1,
                          }));
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="grid gap-1.5">
                        <Label>من آية</Label>
                        <Input
                          type="number"
                          min={1}
                          value={draft.fromAyah}
                          onChange={(e) =>
                            setDraft((d) => ({
                              ...d,
                              fromAyah: clampAyah(d.fromSurah, Number(e.target.value) || 1),
                            }))
                          }
                        />
                      </div>
                      <div className="grid gap-1.5">
                        <Label>إلى آية</Label>
                        <Input
                          type="number"
                          min={1}
                          value={draft.toAyah}
                          onChange={(e) =>
                            setDraft((d) => ({
                              ...d,
                              toAyah: clampAyah(d.toSurah, Number(e.target.value) || 1),
                            }))
                          }
                        />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        className="flex-1"
                        onClick={() => {
                          setDayPlan(profile.id, day, draft);
                          setEditing(null);
                        }}
                      >
                        حفظ المقدار
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() => {
                          setDayPlan(profile.id, day, null);
                          setEditing(null);
                        }}
                      >
                        مسح
                      </Button>
                    </div>
                  </div>
                ) : null}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="rounded-xl">
        <CardContent className="py-4">
          <p className="text-sm font-medium">الجمعة والسبت</p>
          <p className="mt-1 text-sm text-muted-foreground">
            أيام راحة في جدول الحلقة. يمكنك التسميع متى شئت من قسم الحفظ أو الربط.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
