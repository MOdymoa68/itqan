import { createFileRoute, redirect } from "@tanstack/react-router";
import { SessionRecorder } from "@/components/session-recorder";
import type { SessionType } from "@/lib/types";

const TYPES: SessionType[] = ["hifz", "rabt", "murajaa"];

export const Route = createFileRoute("/recite/$type")({
  beforeLoad: ({ params }) => {
    if (!TYPES.includes(params.type as SessionType)) {
      throw redirect({ to: "/recite/$type", params: { type: "hifz" } });
    }
  },
  component: RecitePage,
});

function RecitePage() {
  const { type } = Route.useParams();
  return <SessionRecorder type={type as SessionType} />;
}
