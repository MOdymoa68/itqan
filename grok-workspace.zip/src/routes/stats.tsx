import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { averageItqan, countByKind, sessionItqan } from "@/lib/itqan";
import { repeatedWords } from "@/lib/report";
import { useActiveProfile, useProfileSessions } from "@/lib/store";
import { rangeLabel } from "@/lib/surahs";
import { ERROR_LABEL, SESSION_LABEL } from "@/lib/types";

export const Route = createFileRoute("/stats")({ component: StatsPage });

function StatsPage() {
  const profile = useActiveProfile();
  const all = useProfileSessions(profile?.id ?? null);
  const sessions = all.filter((x) => x.completed);

  const totals = countByKind(sessions.flatMap((s) => s.errors));
  const avg = averageItqan(sessions);
  const weakWords = repeatedWords(sessions, 2).slice(0, 12);
  const ayahMap = new Map<string, { label: string; count: number }>();
  for (const s of sessions) {
    for (const e of s.errors) {
      if (!e.surahId || !e.ayahNumber) continue;
      const key = `${e.surahId}:${e.ayahNumber}`;
      const prev = ayahMap.get(key);
      ayahMap.set(key, {
        label: `${rangeLabel(e.surahId, e.surahId)} ${e.ayahNumber}`,
        count: (prev?.count ?? 0) + 1,
      });
    }
  }
  const weakAyahs = [...ayahMap.values()].filter((x) => x.count >= 2).sort((a, b) => b.count - a.count).slice(0, 8);

  const byType = (["hifz", "rabt", "murajaa"] as const).map((t) => {
    const list = sessions.filter((s) => s.type === t);
    return {
      name: SESSION_LABEL[t],
      إتقان: list.length ? Math.round(list.reduce((n, s) => n + sessionItqan(s), 0) / list.length) : 0,
      جلسات: list.length,
    };
  });

  return (
    <div className="grid gap-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">الإحصاء</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            نقاط الضعف المتكررة ومعدّل الإتقان عبر أنواع التسميع.
          </p>
        </div>
        <Button asChild variant="outline" size="sm">
          <Link to="/report">تصدير تقرير</Link>
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Card>
          <CardContent>
            <p className="text-xs font-medium text-muted-foreground">متوسط الإتقان</p>
            <p className="mt-1 font-display text-4xl text-primary tabular-nums">
              {avg == null ? "—" : `${avg}%`}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">{sessions.length} جلسة</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="grid gap-1.5">
            {(
              [
                ["stop", totals.stop],
                ["lahn", totals.lahn],
                ["note", totals.note],
              ] as const
            ).map(([k, n]) => (
              <div key={k} className="flex justify-between text-sm">
                <span>{ERROR_LABEL[k]}</span>
                <span className="tabular-nums font-medium">{n}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent>
          <p className="mb-3 text-sm font-medium">الإتقان حسب النوع</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byType} barSize={28}>
                <CartesianGrid stroke="var(--color-border)" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
                <YAxis
                  domain={[0, 100]}
                  tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }}
                  orientation="right"
                />
                <Tooltip
                  cursor={{ fill: "var(--color-muted)" }}
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                    direction: "rtl",
                  }}
                />
                <Bar dataKey="إتقان" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="grid gap-3">
          <p className="text-sm font-medium">كلمات تكرر فيها الخطأ</p>
          {weakWords.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              ستظهر هنا الكلمات التي أخطأت فيها أكثر من مرة.
            </p>
          ) : (
            <ul className="grid gap-2">
              {weakWords.map((w) => (
                <li
                  key={w.word}
                  className="flex items-center justify-between rounded-lg bg-muted/70 px-3 py-2"
                >
                  <span>
                    <span className="font-display text-xl">{w.word}</span>
                    {w.ayah ? (
                      <span className="mr-2 text-xs text-muted-foreground">{w.ayah}</span>
                    ) : null}
                  </span>
                  <Badge variant="stop">{w.count}×</Badge>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="grid gap-3">
          <p className="text-sm font-medium">آيات متكررة الخطأ</p>
          {weakAyahs.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا آيات متكررة حتى الآن.</p>
          ) : (
            <ul className="grid gap-2">
              {weakAyahs.map((a) => (
                <li key={a.label} className="flex items-center justify-between text-sm">
                  <span>{a.label}</span>
                  <span className="tabular-nums font-medium">{a.count}</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
