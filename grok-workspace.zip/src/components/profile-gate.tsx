import { useState } from "react";
import { UserPlus } from "lucide-react";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useItqanStore } from "@/lib/store";
import { APP_NAME, CIRCLE_NAME } from "@/lib/types";

export function ProfileGate({ children }: { children: React.ReactNode }) {
  const profiles = useItqanStore((s) => s.profiles);
  const active = useItqanStore((s) => s.activeProfileId);
  const addProfile = useItqanStore((s) => s.addProfile);
  const setActive = useItqanStore((s) => s.setActiveProfile);
  const [name, setName] = useState("");

  if (active && profiles.some((p) => p.id === active)) {
    return <>{children}</>;
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    addProfile(name);
    setName("");
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center gap-6 px-5 py-10">
      <div className="flex flex-col items-center text-center">
        <Logo className="size-14" />
        <h1 className="mt-4 font-display text-4xl text-primary">{APP_NAME}</h1>
        <p className="mt-1 text-sm font-medium text-muted-foreground">{CIRCLE_NAME}</p>
        <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
          رفيقك الفردي لتدوين أخطاء التسميع، وتصحيح الكلمة وفق رسم المصحف، ومتابعة نسبة الإتقان.
        </p>
      </div>

      <Card>
        <CardContent className="grid gap-4">
          <form onSubmit={submit} className="grid gap-3">
            <Label htmlFor="student-name">اسم الطالب</Label>
            <Input
              id="student-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: عبدالله"
              autoComplete="name"
            />
            <Button type="submit" disabled={!name.trim()}>
              <UserPlus className="size-4" />
              إنشاء ملف على هذا الجهاز
            </Button>
          </form>
          {profiles.length > 0 ? (
            <div className="grid gap-2">
              <p className="text-xs font-medium text-muted-foreground">الملفات الموجودة</p>
              {profiles.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setActive(p.id)}
                  className="flex h-11 items-center justify-between rounded-lg bg-muted px-3 text-sm hover:bg-secondary"
                >
                  <span className="font-medium">{p.name}</span>
                  <span className="text-xs text-muted-foreground">دخول</span>
                </button>
              ))}
            </div>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}
