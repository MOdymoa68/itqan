import { useEffect, useMemo, useState } from "react";
import { Minus, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AyahView } from "@/components/ayah-view";
import { SurahPicker } from "@/components/surah-picker";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { countByKind, sessionItqan } from "@/lib/itqan";
import { loadQuran, searchWord, type QuranData, type WordHit } from "@/lib/quran";
import { clampAyah, makeError, useItqanStore } from "@/lib/store";
import { SURAH_BY_ID } from "@/lib/surahs";
import {
  ERROR_HINT,
  ERROR_LABEL,
  SESSION_LABEL,
  type ErrorKind,
  type RecitationError,
  type SessionType,
} from "@/lib/types";
import { cn } from "@/lib/utils";

const KINDS: ErrorKind[] = ["stop", "lahn", "note"];

const kindStyle: Record<ErrorKind, string> = {
  stop: "bg-stop-soft text-stop",
  lahn: "bg-lahn-soft text-lahn",
  note: "bg-note-soft text-note",
};

export function SessionRecorder({ type }: { type: SessionType }) {
  const isRange = type !== "hifz";
  const profileId = useItqanStore((s) => s.activeProfileId);
  const completeSession = useItqanStore((s) => s.completeSession);

  const [fromSurah, setFromSurah] = useState(1);
  const [toSurah, setToSurah] = useState(1);
  const [fromAyah, setFromAyah] = useState(1);
  const [toAyah, setToAyah] = useState(7);
  const [started, setStarted] = useState(false);
  const [kind, setKind] = useState<ErrorKind>("lahn");
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<WordHit[]>([]);
  const [picked, setPicked] = useState<WordHit | null>(null);
  const [errors, setErrors] = useState<RecitationError[]>([]);
  const [quran, setQuran] = useState<QuranData | null>(null);
  const [doneScore, setDoneScore] = useState<number | null>(null);

  useEffect(() => {
    void loadQuran().then(setQuran);
  }, []);

  useEffect(() => {
    const s = SURAH_BY_ID[fromSurah];
    if (!s) return;
    setFromAyah(1);
    if (!isRange) {
      setToSurah(fromSurah);
      setToAyah(s.ayahs);
    }
  }, [fromSurah, isRange]);

  useEffect(() => {
    if (!isRange) return;
    const s = SURAH_BY_ID[toSurah];
    if (!s) return;
    setToAyah(s.ayahs);
  }, [toSurah, isRange]);

  useEffect(() => {
    if (!started || !quran || query.trim().length < 2) {
      setHits([]);
      return;
    }
    const t = window.setTimeout(() => {
      const result = searchWord(quran, query, {
        fromSurah,
        toSurah: isRange ? toSurah : fromSurah,
        fromAyah,
        toAyah: isRange ? toAyah : toAyah,
      });
      setHits(result);
      setPicked(result[0] ?? null);
    }, 140);
    return () => window.clearTimeout(t);
  }, [query, quran, started, fromSurah, toSurah, fromAyah, toAyah, isRange]);

  const counts = useMemo(() => countByKind(errors), [errors]);

  function addDetailed() {
    const word = query.trim();
    if (!word && !picked) {
      toast("اكتب الكلمة أو زد العداد مباشرة");
      return;
    }
    const next = makeError(kind, {
      word,
      surahId: picked?.surahId ?? fromSurah,
      ayahNumber: picked?.ayahNumber ?? null,
      ayahText: picked?.ayahText ?? "",
      matchedWord: picked?.word ?? word,
      wordIndex: picked?.wordIndex ?? null,
    });
    setErrors((e) => [next, ...e]);
    setQuery("");
    setHits([]);
    setPicked(null);
  }

  function bump(k: ErrorKind, delta: number) {
    if (delta > 0) {
      setErrors((e) => [makeError(k), ...e]);
      setKind(k);
    } else {
      setErrors((e) => {
        const idx = e.findIndex((x) => x.kind === k);
        if (idx === -1) return e;
        return e.filter((_, i) => i !== idx);
      });
    }
  }

  function finish() {
    if (!profileId) return;
    const session = completeSession({
      profileId,
      type,
      fromSurah,
      toSurah: isRange ? toSurah : fromSurah,
      fromAyah,
      toAyah,
      errors,
    });
    setDoneScore(sessionItqan(session));
    setStarted(false);
    setErrors([]);
    toast.success("أُغلق التسميع وحُفظ في السجل");
  }

  if (doneScore != null) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-4 py-10 text-center">
          <p className="text-sm font-medium text-muted-foreground">نسبة الإتقان</p>
          <p className="font-display text-6xl text-primary tabular-nums">{doneScore}%</p>
          <p className="max-w-xs text-sm text-muted-foreground">
            {doneScore >= 90
              ? "إتقان عالٍ. ثبّت الموضع بمراجعة خفيفة."
              : doneScore >= 70
                ? "جيد. راجع مواضع اللحن قبل الجلسة القادمة."
                : "ركّز على الكلمات المتكررة في صفحة الإحصاء."}
          </p>
          <Button onClick={() => setDoneScore(null)}>تسميع جديد</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="text-2xl font-semibold">{SESSION_LABEL[type]}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {type === "hifz"
            ? "حدد السورة المقررة، ثم سجّل مواضع الخطأ أثناء التسميع."
            : "حدد المدى من سورة إلى سورة، ثم وثّق الأخطاء واللحون والتنبيهات."}
        </p>
      </div>

      <Card>
        <CardContent className="grid gap-4">
          {isRange ? (
            <div className="grid gap-3 sm:grid-cols-2">
              <SurahPicker label="من سورة" value={fromSurah} onChange={setFromSurah} />
              <SurahPicker label="إلى سورة" value={toSurah} onChange={setToSurah} />
            </div>
          ) : (
            <SurahPicker label="السورة المقررة" value={fromSurah} onChange={setFromSurah} />
          )}
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="from-ayah">من آية</Label>
              <Input
                id="from-ayah"
                type="number"
                min={1}
                value={fromAyah}
                onChange={(e) => setFromAyah(clampAyah(fromSurah, Number(e.target.value) || 1))}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="to-ayah">إلى آية</Label>
              <Input
                id="to-ayah"
                type="number"
                min={1}
                value={toAyah}
                onChange={(e) =>
                  setToAyah(
                    clampAyah(isRange ? toSurah : fromSurah, Number(e.target.value) || 1),
                  )
                }
              />
            </div>
          </div>
          {!started ? (
            <Button
              size="lg"
              onClick={() => {
                setStarted(true);
                setDoneScore(null);
              }}
            >
              بدء التسميع
            </Button>
          ) : null}
        </CardContent>
      </Card>

      {started ? (
        <>
          <div className="grid grid-cols-3 gap-2">
            {KINDS.map((k) => (
              <Card key={k} className="rounded-xl">
                <CardContent className="px-2 py-3 text-center">
                  <p className="text-xs font-medium text-muted-foreground">{ERROR_LABEL[k]}</p>
                  <p className="mt-1 font-display text-3xl tabular-nums leading-none">
                    {counts[k]}
                  </p>
                  <div className="mt-2 flex justify-center gap-1">
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      className="size-9 min-h-9 min-w-9"
                      onClick={() => bump(k, -1)}
                      aria-label={`إنقاص ${ERROR_LABEL[k]}`}
                    >
                      <Minus className="size-3.5" />
                    </Button>
                    <Button
                      type="button"
                      size="icon"
                      variant="secondary"
                      className="size-9 min-h-9 min-w-9"
                      onClick={() => bump(k, 1)}
                      aria-label={`زيادة ${ERROR_LABEL[k]}`}
                    >
                      <Plus className="size-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardContent className="grid gap-3">
              <p className="text-sm font-medium">تسجيل كلمة الخطأ</p>
              <div className="flex gap-1 rounded-xl bg-muted p-1">
                {KINDS.map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setKind(k)}
                    className={cn(
                      "h-9 flex-1 rounded-lg text-xs font-medium transition-colors",
                      kind === k ? kindStyle[k] : "text-muted-foreground",
                    )}
                  >
                    {ERROR_LABEL[k]}
                  </button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">{ERROR_HINT[kind]}</p>
              <div className="relative">
                <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="اكتب الكلمة كما نطقها الطالب"
                  className="pr-10"
                  dir="rtl"
                />
              </div>
              {hits.length > 0 ? (
                <ul className="grid gap-2">
                  {hits.map((h) => (
                    <li key={`${h.surahId}-${h.ayahNumber}-${h.wordIndex}`}>
                      <button
                        type="button"
                        onClick={() => setPicked(h)}
                        className={cn(
                          "w-full rounded-xl border p-2 text-right transition-colors",
                          picked?.surahId === h.surahId &&
                            picked.ayahNumber === h.ayahNumber &&
                            picked.wordIndex === h.wordIndex
                            ? "border-primary bg-secondary"
                            : "border-border bg-card hover:bg-muted",
                        )}
                      >
                        <AyahView hit={h} className="bg-transparent p-1" />
                      </button>
                    </li>
                  ))}
                </ul>
              ) : query.trim().length >= 2 ? (
                <p className="text-sm text-muted-foreground">
                  لم يُعثر على الكلمة في النطاق. يمكنك إضافتها يدويًا.
                </p>
              ) : null}
              {picked ? (
                <p className="text-sm">
                  التصحيح:{" "}
                  <span className="font-display text-lg text-primary">{picked.word}</span>
                </p>
              ) : null}
              <Button onClick={addDetailed} variant="secondary">
                إضافة الموضع
              </Button>
            </CardContent>
          </Card>

          {errors.length > 0 ? (
            <Card>
              <CardContent className="grid gap-2">
                <p className="text-sm font-medium">سجل هذه الجلسة</p>
                {errors.map((e) => (
                  <div
                    key={e.id}
                    className="flex items-start justify-between gap-2 rounded-xl bg-muted/70 px-3 py-2"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant={e.kind}>{ERROR_LABEL[e.kind]}</Badge>
                        {e.matchedWord || e.word ? (
                          <span className="font-display text-lg">{e.matchedWord || e.word}</span>
                        ) : (
                          <span className="text-sm text-muted-foreground">بدون كلمة</span>
                        )}
                      </div>
                      {e.ayahNumber ? (
                        <p className="mt-1 text-xs text-muted-foreground">
                          {SURAH_BY_ID[e.surahId ?? 0]?.name} · آية {e.ayahNumber}
                        </p>
                      ) : null}
                    </div>
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      className="size-9"
                      onClick={() => setErrors((list) => list.filter((x) => x.id !== e.id))}
                      aria-label="حذف"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          ) : null}

          <Button size="lg" onClick={finish}>
            إنهاء الجلسة وحفظها
          </Button>
        </>
      ) : null}
    </div>
  );
}
