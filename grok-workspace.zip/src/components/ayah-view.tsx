import { SURAH_BY_ID } from "@/lib/surahs";
import { splitWords, type WordHit } from "@/lib/quran";
import { cn } from "@/lib/utils";

export function AyahView({
  hit,
  className,
}: {
  hit: Pick<WordHit, "surahId" | "ayahNumber" | "ayahText" | "wordIndex">;
  className?: string;
}) {
  const surah = SURAH_BY_ID[hit.surahId];
  const words = splitWords(hit.ayahText);

  return (
    <figure className={cn("rounded-xl bg-muted/70 px-4 py-3", className)}>
      <figcaption className="mb-2 text-xs font-medium text-muted-foreground">
        {surah?.name} · آية {hit.ayahNumber}
      </figcaption>
      <p className="font-display text-xl leading-loose text-foreground" dir="rtl">
        {words.map((w, i) => (
          <span key={`${i}-${w}`}>
            {i > 0 ? " " : null}
            <span className={i === hit.wordIndex ? "ayah-mark" : undefined}>{w}</span>
          </span>
        ))}
      </p>
    </figure>
  );
}
