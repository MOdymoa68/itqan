import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  BookOpen,
  CalendarDays,
  Home,
  Plus,
  ScrollText,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";
import { Logo } from "@/components/logo";
import { ProfileGate } from "@/components/profile-gate";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { useActiveProfile, useItqanStore } from "@/lib/store";
import { APP_NAME, CIRCLE_NAME } from "@/lib/types";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "الرئيسية", icon: Home, match: undefined, params: undefined },
  {
    to: "/recite/$type",
    label: "تسميع",
    icon: BookOpen,
    match: "/recite",
    params: { type: "hifz" as const },
  },
  { to: "/schedule", label: "الجدول", icon: CalendarDays, match: undefined, params: undefined },
  { to: "/history", label: "السجل", icon: ScrollText, match: undefined, params: undefined },
  { to: "/stats", label: "إحصاء", icon: BarChart3, match: undefined, params: undefined },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const profile = useActiveProfile();
  const profiles = useItqanStore((s) => s.profiles);
  const setActive = useItqanStore((s) => s.setActiveProfile);
  const addProfile = useItqanStore((s) => s.addProfile);
  const renameProfile = useItqanStore((s) => s.renameProfile);
  const deleteProfile = useItqanStore((s) => s.deleteProfile);
  const [addOpen, setAddOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [renameOpen, setRenameOpen] = useState(false);
  const [renameValue, setRenameValue] = useState("");

  useEffect(() => {
    void Promise.resolve(useItqanStore.persist.rehydrate()).then(() => {
      useItqanStore.getState().setHydrated(true);
    });
  }, []);

  return (
    <ProfileGate>
      <div className="app-frame min-h-dvh bg-background text-foreground">
        <header className="sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-sm">
          <div className="mx-auto flex h-14 max-w-3xl items-center justify-between gap-3 px-4">
            <Link to="/" className="flex items-center gap-2">
              <Logo className="size-8" />
              <span className="leading-tight">
                <span className="block font-display text-xl leading-none text-primary">
                  {APP_NAME}
                </span>
                <span className="block max-w-40 truncate text-xs text-muted-foreground">
                  {CIRCLE_NAME}
                </span>
              </span>
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="max-w-40 gap-2">
                  <UserRound className="size-4" />
                  <span className="truncate">{profile?.name ?? "الملف"}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuLabel>ملفات هذا الجهاز</DropdownMenuLabel>
                {profiles.map((p) => (
                  <DropdownMenuItem key={p.id} onSelect={() => setActive(p.id)}>
                    <span className={cn("flex-1", p.id === profile?.id && "font-semibold")}>
                      {p.name}
                    </span>
                    {p.id === profile?.id ? (
                      <span className="text-xs text-primary">الحالي</span>
                    ) : null}
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onSelect={() => {
                    setRenameValue(profile?.name ?? "");
                    setRenameOpen(true);
                  }}
                >
                  إعادة تسمية
                </DropdownMenuItem>
                <DropdownMenuItem
                  onSelect={() => {
                    setNewName("");
                    setAddOpen(true);
                  }}
                >
                  <Plus className="size-4" />
                  إضافة طالب
                </DropdownMenuItem>
                {profile && profiles.length > 0 ? (
                  <DropdownMenuItem
                    className="text-destructive"
                    onSelect={() => {
                      deleteProfile(profile.id);
                      toast("أُزيل الملف من هذا الجهاز");
                    }}
                  >
                    حذف الملف الحالي
                  </DropdownMenuItem>
                ) : null}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="mx-auto w-full max-w-3xl px-4 pt-5 pb-28">{children}</main>

        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm">
          <ul className="mx-auto grid max-w-3xl grid-cols-5 px-1">
            {NAV.map((item) => {
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : item.match
                    ? pathname.startsWith(item.match)
                    : pathname === item.to;
              const Icon = item.icon;
              return (
                <li key={item.label}>
                  <Link
                    to={item.to}
                    params={item.params}
                    className={cn(
                      "flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs font-medium",
                      active ? "text-primary" : "text-muted-foreground",
                    )}
                  >
                    <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>طالب جديد</DialogTitle>
              <DialogDescription>
                يُحفظ الملف على هذا الجهاز فقط، ويمكن التبديل في أي وقت.
              </DialogDescription>
            </DialogHeader>
            <form
              className="grid gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                if (!newName.trim()) return;
                addProfile(newName);
                setAddOpen(false);
                setNewName("");
              }}
            >
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="اسم الطالب"
              />
              <Button type="submit">إضافة</Button>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={renameOpen} onOpenChange={setRenameOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>إعادة تسمية الملف</DialogTitle>
            </DialogHeader>
            <form
              className="grid gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                if (!profile || !renameValue.trim()) return;
                renameProfile(profile.id, renameValue);
                setRenameOpen(false);
              }}
            >
              <Input value={renameValue} onChange={(e) => setRenameValue(e.target.value)} />
              <Button type="submit">حفظ</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </ProfileGate>
  );
}
