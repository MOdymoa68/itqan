import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className={cn("size-9", className)}
    >
      <rect width="48" height="48" rx="12" fill="currentColor" className="text-primary" />
      <path
        d="M12 16.5c0-.8.6-1.5 1.4-1.5h9.2c.4 0 .8.2 1.1.5L28 20h6.6c.8 0 1.4.7 1.4 1.5v14c0 .8-.6 1.5-1.4 1.5H13.4c-.8 0-1.4-.7-1.4-1.5v-19Z"
        fill="currentColor"
        className="text-primary-foreground"
        opacity="0.16"
      />
      <path
        d="M14 18h9l4 4h7v14H14V18Z"
        stroke="currentColor"
        className="text-primary-foreground"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path
        d="M23 18v4h4"
        stroke="currentColor"
        className="text-primary-foreground"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path
        d="M18 28.5h12M18 32.5h8"
        stroke="currentColor"
        className="text-primary-foreground"
        strokeWidth="1.5"
        strokeLinecap="round"
        opacity="0.8"
      />
      <circle cx="24" cy="24.5" r="1.6" fill="currentColor" className="text-primary-foreground" />
    </svg>
  );
}
