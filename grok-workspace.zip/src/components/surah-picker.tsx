import { useMemo, useState } from "react";
import { ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { SURAHS, SURAH_BY_ID } from "@/lib/surahs";
import { normalizeArabic } from "@/lib/quran";
import { cn } from "@/lib/utils";

export function SurahPicker({
  value,
  onChange,
  label,
  className,
}: {
  value: number;
  onChange: (id: number) => void;
  label?: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const selected = SURAH_BY_ID[value];

  const filtered = useMemo(() => {
    const n = normalizeArabic(q);
    const num = Number(q);
    return SURAHS.filter((s) => {
      if (!q.trim()) return true;
      if (!Number.isNaN(num) && s.id === num) return true;
      return (
        normalizeArabic(s.name).includes(n) ||
        s.latin.toLowerCase().includes(q.toLowerCase()) ||
        String(s.id).includes(q.trim())
      );
    });
  }, [q]);

  return (
    <div className={cn("grid gap-1.5", className)}>
      {label ? <span className="text-sm font-medium">{label}</span> : null}
      <Button
        type="button"
        variant="outline"
        className="h-11 w-full justify-between font-normal"
        onClick={() => setOpen(true)}
      >
        <span>{selected ? `${selected.id}. ${selected.name}` : "اختر سورة"}</span>
        <ChevronsUpDown className="size-4 text-muted-foreground" />
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[80vh] overflow-hidden p-0">
          <DialogHeader className="px-5 pt-5">
            <DialogTitle>اختيار السورة</DialogTitle>
          </DialogHeader>
          <div className="px-5 pb-2">
            <Input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث بالاسم أو الرقم"
            />
          </div>
          <div className="max-h-[50vh] overflow-y-auto px-2 pb-4">
            {filtered.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => {
                  onChange(s.id);
                  setOpen(false);
                  setQ("");
                }}
                className={cn(
                  "flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-right text-sm hover:bg-muted",
                  s.id === value && "bg-secondary text-secondary-foreground",
                )}
              >
                <span className="font-medium">
                  {s.id}. {s.name}
                </span>
                <span className="text-xs text-muted-foreground">{s.ayahs} آية</span>
              </button>
            ))}
            {filtered.length === 0 ? (
              <p className="px-3 py-8 text-center text-sm text-muted-foreground">لا توجد نتائج</p>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
