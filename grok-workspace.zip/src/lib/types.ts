export const CIRCLE_NAME = "حلقة ربعي بن عمرو الأنصاري";
export const APP_NAME = "إتقان";

export type SessionType = "hifz" | "rabt" | "murajaa";
export type ErrorKind = "stop" | "lahn" | "note";

export const SESSION_LABEL: Record<SessionType, string> = {
  hifz: "حفظ جديد",
  rabt: "ربط",
  murajaa: "مراجعة",
};

export const ERROR_LABEL: Record<ErrorKind, string> = {
  stop: "أخطاء",
  lahn: "لحون",
  note: "تنبيهات",
};

export const ERROR_HINT: Record<ErrorKind, string> = {
  stop: "توقف أو نسيان كلمة",
  lahn: "لحن جلي أو خفي / تغيير حركة",
  note: "ترديد أو تردد",
};

export type Profile = {
  id: string;
  name: string;
  createdAt: string;
  tint: number;
};

export type RecitationError = {
  id: string;
  kind: ErrorKind;
  word: string;
  surahId: number | null;
  ayahNumber: number | null;
  ayahText: string;
  matchedWord: string;
  wordIndex: number | null;
  createdAt: string;
};

export type Session = {
  id: string;
  profileId: string;
  type: SessionType;
  date: string;
  fromSurah: number;
  toSurah: number;
  fromAyah: number;
  toAyah: number;
  errors: RecitationError[];
  completed: boolean;
  createdAt: string;
  endedAt: string | null;
};

export type DayPlan = {
  fromSurah: number;
  toSurah: number;
  fromAyah: number;
  toAyah: number;
};

export type WeekSchedule = {
  /** Sunday=0 … Thursday=4 */
  days: Record<number, DayPlan | null>;
};

export type DraftSession = {
  type: SessionType;
  fromSurah: number;
  toSurah: number;
  fromAyah: number;
  toAyah: number;
  errors: RecitationError[];
};
