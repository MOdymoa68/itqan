import { countAyahsInRange } from "@/lib/surahs";
import type { ErrorKind, RecitationError, Session } from "@/lib/types";

const WEIGHT: Record<ErrorKind, number> = {
  stop: 5,
  lahn: 3,
  note: 1,
};

export function countByKind(errors: RecitationError[]): Record<ErrorKind, number> {
  const out: Record<ErrorKind, number> = { stop: 0, lahn: 0, note: 0 };
  for (const e of errors) out[e.kind] += 1;
  return out;
}

export function sessionItqan(session: Pick<Session, "errors" | "fromSurah" | "toSurah" | "fromAyah" | "toAyah">): number {
  const ayahs = Math.max(
    1,
    countAyahsInRange(session.fromSurah, session.toSurah, session.fromAyah, session.toAyah),
  );
  const penalty =
    session.errors.reduce((sum, e) => sum + WEIGHT[e.kind], 0) / ayahs;
  const score = 100 - penalty * 12;
  return Math.max(0, Math.min(100, Math.round(score)));
}

export function averageItqan(sessions: Session[]): number | null {
  const done = sessions.filter((s) => s.completed);
  if (done.length === 0) return null;
  const total = done.reduce((sum, s) => sum + sessionItqan(s), 0);
  return Math.round(total / done.length);
}

export function itqanTone(score: number): "high" | "mid" | "low" {
  if (score >= 90) return "high";
  if (score >= 70) return "mid";
  return "low";
}
