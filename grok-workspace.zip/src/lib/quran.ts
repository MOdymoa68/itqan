import { SURAHS, type SurahMeta } from "@/lib/surahs";

export type QuranData = {
  surahs: SurahMeta[];
  verses: string[][];
};

export type WordHit = {
  surahId: number;
  ayahNumber: number;
  ayahText: string;
  wordIndex: number;
  word: string;
  score: number;
};

const TASHKEEL_RE =
  /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08E1\u08E3-\u08FF\u0640]/g;

export function stripTashkeel(input: string): string {
  return input.replace(TASHKEEL_RE, "");
}

export function normalizeArabic(input: string): string {
  return stripTashkeel(input)
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[^\u0621-\u063A\u0641-\u064A\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function splitWords(ayah: string): string[] {
  return ayah.trim().split(/\s+/).filter(Boolean);
}

let cache: QuranData | null = null;
let pending: Promise<QuranData> | null = null;

export function loadQuran(): Promise<QuranData> {
  if (cache) return Promise.resolve(cache);
  if (typeof window === "undefined") {
    return Promise.resolve({ surahs: SURAHS, verses: [] });
  }
  if (!pending) {
    pending = fetch("/data/quran.json")
      .then((r) => {
        if (!r.ok) throw new Error("quran fetch failed");
        return r.json() as Promise<QuranData>;
      })
      .then((data) => {
        cache = data;
        return data;
      });
  }
  return pending;
}

export function getAyah(data: QuranData, surahId: number, ayahNumber: number): string | null {
  const surah = data.verses[surahId - 1];
  if (!surah) return null;
  return surah[ayahNumber - 1] ?? null;
}

export function searchWord(
  data: QuranData,
  query: string,
  range: { fromSurah: number; toSurah: number; fromAyah: number; toAyah: number },
  limit = 8,
): WordHit[] {
  const q = normalizeArabic(query);
  if (q.length < 2) return [];

  const qTokens = q.split(" ").filter(Boolean);
  const hits: WordHit[] = [];

  const start = Math.min(range.fromSurah, range.toSurah);
  const end = Math.max(range.fromSurah, range.toSurah);

  for (let sid = start; sid <= end; sid++) {
    const verses = data.verses[sid - 1];
    if (!verses) continue;
    const first = sid === start ? range.fromAyah : 1;
    const last = sid === end ? range.toAyah : verses.length;

    for (let a = first; a <= last; a++) {
      const text = verses[a - 1];
      if (!text) continue;
      const words = splitWords(text);
      const norm = words.map(normalizeArabic);

      if (qTokens.length > 1) {
        const joined = norm.join(" ");
        const idx = joined.indexOf(q);
        if (idx >= 0) {
          let cursor = 0;
          let wordIndex = 0;
          for (let i = 0; i < norm.length; i++) {
            if (cursor === idx || (cursor < idx && cursor + norm[i]!.length >= idx)) {
              wordIndex = i;
              break;
            }
            cursor += norm[i]!.length + 1;
          }
          hits.push({
            surahId: sid,
            ayahNumber: a,
            ayahText: text,
            wordIndex,
            word: words[wordIndex] ?? "",
            score: 90,
          });
        }
      } else {
        for (let i = 0; i < norm.length; i++) {
          const w = norm[i]!;
          if (!w) continue;
          let score = 0;
          if (w === q) score = 100;
          else if (w.startsWith(q)) score = 80 - Math.min(20, w.length - q.length);
          else if (w.includes(q)) score = 50;
          if (score > 0) {
            hits.push({
              surahId: sid,
              ayahNumber: a,
              ayahText: text,
              wordIndex: i,
              word: words[i]!,
              score,
            });
          }
        }
      }

      if (hits.length > 80) break;
    }
    if (hits.length > 80) break;
  }

  hits.sort((a, b) => b.score - a.score || a.surahId - b.surahId || a.ayahNumber - b.ayahNumber);

  const seen = new Set<string>();
  const unique: WordHit[] = [];
  for (const h of hits) {
    const key = `${h.surahId}:${h.ayahNumber}:${h.wordIndex}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(h);
    if (unique.length >= limit) break;
  }
  return unique;
}
