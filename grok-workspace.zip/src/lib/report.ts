import { averageItqan, countByKind, sessionItqan } from "@/lib/itqan";
import { rangeLabel } from "@/lib/surahs";
import { APP_NAME, CIRCLE_NAME, ERROR_LABEL, SESSION_LABEL, type Profile, type Session } from "@/lib/types";
import { addDays, formatArDate, startOfWeekSunday, todayISO, WEEKDAYS_AR } from "@/lib/utils";

function repeatedWords(sessions: Session[], min = 2) {
  const map = new Map<string, { word: string; count: number; ayah: string }>();
  for (const s of sessions) {
    for (const e of s.errors) {
      const key = (e.matchedWord || e.word).trim();
      if (!key) continue;
      const prev = map.get(key);
      const ayah =
        e.surahId && e.ayahNumber
          ? `${rangeLabel(e.surahId, e.surahId)} ${e.ayahNumber}`
          : prev?.ayah ?? "";
      map.set(key, { word: key, count: (prev?.count ?? 0) + 1, ayah });
    }
  }
  return [...map.values()].filter((x) => x.count >= min).sort((a, b) => b.count - a.count);
}

export function weekSessions(sessions: Session[], weekStart: Date): Session[] {
  const start = todayISO(weekStart);
  const end = todayISO(addDays(weekStart, 6));
  return sessions.filter((s) => s.date >= start && s.date <= end && s.completed);
}

export async function downloadWeeklyPng(profile: Profile, sessions: Session[]): Promise<void> {
  const weekStart = startOfWeekSunday();
  const week = weekSessions(sessions, weekStart);
  const counts = countByKind(week.flatMap((s) => s.errors));
  const avg = averageItqan(week);
  const weak = repeatedWords(week, 2).slice(0, 6);
  const end = addDays(weekStart, 4);

  const W = 1080;
  const H = 1520;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  await document.fonts.ready;

  ctx.fillStyle = "#f3eee4";
  ctx.fillRect(0, 0, W, H);

  ctx.fillStyle = "#1e4d3a";
  ctx.fillRect(0, 0, W, 220);

  ctx.fillStyle = "#f4efe6";
  ctx.textAlign = "right";
  ctx.direction = "rtl";
  ctx.font = "700 64px Amiri, serif";
  ctx.fillText(APP_NAME, W - 72, 100);
  ctx.font = "500 28px 'IBM Plex Sans Arabic', sans-serif";
  ctx.fillText(CIRCLE_NAME, W - 72, 150);
  ctx.font = "400 22px 'IBM Plex Sans Arabic', sans-serif";
  ctx.fillStyle = "#c9d7cf";
  ctx.fillText("تقرير الإنجاز الأسبوعي", W - 72, 190);

  const box = (x: number, y: number, w: number, h: number) => {
    ctx.fillStyle = "#faf7f0";
    ctx.strokeStyle = "#e0d6c6";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 28);
    ctx.fill();
    ctx.stroke();
  };

  ctx.fillStyle = "#1c1915";
  ctx.font = "600 30px 'IBM Plex Sans Arabic', sans-serif";
  ctx.fillText(profile.name, W - 72, 280);
  ctx.font = "400 22px 'IBM Plex Sans Arabic', sans-serif";
  ctx.fillStyle = "#6b6459";
  ctx.fillText(
    `${formatArDate(todayISO(weekStart))}  —  ${formatArDate(todayISO(end))}`,
    W - 72,
    318,
  );

  const cards = [
    { label: "نسبة الإتقان", value: avg == null ? "—" : `${avg}%` },
    { label: "جلسات الأسبوع", value: String(week.length) },
    { label: ERROR_LABEL.stop, value: String(counts.stop) },
    { label: ERROR_LABEL.lahn, value: String(counts.lahn) },
    { label: ERROR_LABEL.note, value: String(counts.note) },
  ];

  cards.forEach((c, i) => {
    const col = i % 5;
    const x = 48 + col * 200;
    const y = 360;
    box(x, y, 184, 140);
    ctx.textAlign = "center";
    ctx.fillStyle = "#1e4d3a";
    ctx.font = "700 40px 'IBM Plex Sans Arabic', sans-serif";
    ctx.fillText(c.value, x + 92, y + 72);
    ctx.fillStyle = "#6b6459";
    ctx.font = "500 18px 'IBM Plex Sans Arabic', sans-serif";
    ctx.fillText(c.label, x + 92, y + 110);
  });

  ctx.textAlign = "right";
  ctx.fillStyle = "#1c1915";
  ctx.font = "700 28px 'IBM Plex Sans Arabic', sans-serif";
  ctx.fillText("التسميع اليومي", W - 72, 560);

  for (let i = 0; i < 5; i++) {
    const date = addDays(weekStart, i);
    const iso = todayISO(date);
    const daySessions = week.filter((s) => s.date === iso);
    const y = 590 + i * 86;
    box(48, y, W - 96, 74);
    ctx.fillStyle = "#1c1915";
    ctx.font = "600 24px 'IBM Plex Sans Arabic', sans-serif";
    ctx.fillText(WEEKDAYS_AR[i]!, W - 80, y + 46);
    ctx.fillStyle = "#6b6459";
    ctx.font = "400 20px 'IBM Plex Sans Arabic', sans-serif";
    if (daySessions.length === 0) {
      ctx.fillText("لم يُسجَّل تسميع", 80, y + 46);
    } else {
      const bits = daySessions.map((s) => {
        const itq = sessionItqan(s);
        return `${SESSION_LABEL[s.type]} · ${rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)} · ${itq}%`;
      });
      ctx.fillText(bits.join("  |  "), 80, y + 46);
    }
  }

  ctx.fillStyle = "#1c1915";
  ctx.font = "700 28px 'IBM Plex Sans Arabic', sans-serif";
  ctx.textAlign = "right";
  ctx.fillText("مواضع تكرر فيها الخطأ", W - 72, 1068);

  box(48, 1090, W - 96, 280);
  if (weak.length === 0) {
    ctx.fillStyle = "#6b6459";
    ctx.font = "400 22px 'IBM Plex Sans Arabic', sans-serif";
    ctx.fillText("لا توجد كلمات متكررة هذا الأسبوع.", W - 80, 1160);
  } else {
    weak.forEach((w, i) => {
      const y = 1140 + i * 36;
      ctx.fillStyle = "#1c1915";
      ctx.font = "600 22px Amiri, serif";
      ctx.fillText(w.word, W - 80, y);
      ctx.fillStyle = "#9b3d32";
      ctx.font = "600 20px 'IBM Plex Sans Arabic', sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(`${w.count}×`, 80, y);
      ctx.textAlign = "right";
    });
  }

  ctx.fillStyle = "#8a8276";
  ctx.font = "400 18px 'IBM Plex Sans Arabic', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(`${APP_NAME} · ${CIRCLE_NAME}`, W / 2, H - 48);

  const url = canvas.toDataURL("image/png");
  const a = document.createElement("a");
  a.href = url;
  a.download = `itqan-${profile.name}-${todayISO()}.png`;
  a.click();
}

export { repeatedWords };
