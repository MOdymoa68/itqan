import { useMemo } from "react";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { sessionItqan } from "@/lib/itqan";
import { SURAH_BY_ID } from "@/lib/surahs";
import type {
  DayPlan,
  ErrorKind,
  Profile,
  RecitationError,
  Session,
  SessionType,
  WeekSchedule,
} from "@/lib/types";
import { todayISO, uid } from "@/lib/utils";

type State = {
  profiles: Profile[];
  activeProfileId: string | null;
  sessions: Session[];
  schedules: Record<string, WeekSchedule>;
  completions: Record<string, Record<string, boolean>>;
  hydrated: boolean;
};

type Actions = {
  setHydrated: (v: boolean) => void;
  addProfile: (name: string) => string;
  renameProfile: (id: string, name: string) => void;
  deleteProfile: (id: string) => void;
  setActiveProfile: (id: string | null) => void;
  setDayPlan: (profileId: string, day: number, plan: DayPlan | null) => void;
  toggleCompletion: (profileId: string, date: string) => void;
  markCompletion: (profileId: string, date: string, done: boolean) => void;
  completeSession: (input: {
    profileId: string;
    type: SessionType;
    fromSurah: number;
    toSurah: number;
    fromAyah: number;
    toAyah: number;
    errors: RecitationError[];
  }) => Session;
  deleteSession: (id: string) => void;
};

const TINTS = [152, 28, 200, 84, 340, 48];

const emptySchedule = (): WeekSchedule => ({
  days: { 0: null, 1: null, 2: null, 3: null, 4: null },
});

export const useItqanStore = create<State & Actions>()(
  persist(
    (set, get) => ({
      profiles: [],
      activeProfileId: null,
      sessions: [],
      schedules: {},
      completions: {},
      hydrated: false,

      setHydrated: (v) => set({ hydrated: v }),

      addProfile: (name) => {
        const trimmed = name.trim();
        const id = uid();
        const tint = TINTS[get().profiles.length % TINTS.length]!;
        const profile: Profile = {
          id,
          name: trimmed || "طالب",
          createdAt: new Date().toISOString(),
          tint,
        };
        set((s) => ({
          profiles: [...s.profiles, profile],
          activeProfileId: id,
          schedules: { ...s.schedules, [id]: emptySchedule() },
        }));
        return id;
      },

      renameProfile: (id, name) => {
        const trimmed = name.trim();
        if (!trimmed) return;
        set((s) => ({
          profiles: s.profiles.map((p) => (p.id === id ? { ...p, name: trimmed } : p)),
        }));
      },

      deleteProfile: (id) => {
        set((s) => {
          const profiles = s.profiles.filter((p) => p.id !== id);
          const { [id]: _s, ...schedules } = s.schedules;
          const { [id]: _c, ...completions } = s.completions;
          const sessions = s.sessions.filter((sess) => sess.profileId !== id);
          const activeProfileId =
            s.activeProfileId === id ? (profiles[0]?.id ?? null) : s.activeProfileId;
          return { profiles, schedules, completions, sessions, activeProfileId };
        });
      },

      setActiveProfile: (id) => set({ activeProfileId: id }),

      setDayPlan: (profileId, day, plan) => {
        set((s) => {
          const current = s.schedules[profileId] ?? emptySchedule();
          return {
            schedules: {
              ...s.schedules,
              [profileId]: {
                days: { ...current.days, [day]: plan },
              },
            },
          };
        });
      },

      toggleCompletion: (profileId, date) => {
        set((s) => {
          const map = s.completions[profileId] ?? {};
          return {
            completions: {
              ...s.completions,
              [profileId]: { ...map, [date]: !map[date] },
            },
          };
        });
      },

      markCompletion: (profileId, date, done) => {
        set((s) => {
          const map = s.completions[profileId] ?? {};
          return {
            completions: {
              ...s.completions,
              [profileId]: { ...map, [date]: done },
            },
          };
        });
      },

      completeSession: (input) => {
        const session: Session = {
          id: uid(),
          profileId: input.profileId,
          type: input.type,
          date: todayISO(),
          fromSurah: input.fromSurah,
          toSurah: input.toSurah,
          fromAyah: input.fromAyah,
          toAyah: input.toAyah,
          errors: input.errors,
          completed: true,
          createdAt: new Date().toISOString(),
          endedAt: new Date().toISOString(),
        };
        set((s) => ({ sessions: [session, ...s.sessions] }));
        get().markCompletion(input.profileId, session.date, true);
        return session;
      },

      deleteSession: (id) => {
        set((s) => ({ sessions: s.sessions.filter((sess) => sess.id !== id) }));
      },
    }),
    {
      name: "itqan-v1",
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      skipHydration: true,
      partialize: (s) => ({
        profiles: s.profiles,
        activeProfileId: s.activeProfileId,
        sessions: s.sessions,
        schedules: s.schedules,
        completions: s.completions,
      }),
    },
  ),
);

export function useActiveProfile(): Profile | null {
  return useItqanStore((s) => s.profiles.find((p) => p.id === s.activeProfileId) ?? null);
}

export function useProfileSessions(profileId: string | null): Session[] {
  const sessions = useItqanStore((s) => s.sessions);
  return useMemo(
    () => (profileId ? sessions.filter((sess) => sess.profileId === profileId) : []),
    [sessions, profileId],
  );
}

export function makeError(
  kind: ErrorKind,
  extra?: Partial<Omit<RecitationError, "id" | "kind" | "createdAt">>,
): RecitationError {
  return {
    id: uid(),
    kind,
    word: extra?.word ?? "",
    surahId: extra?.surahId ?? null,
    ayahNumber: extra?.ayahNumber ?? null,
    ayahText: extra?.ayahText ?? "",
    matchedWord: extra?.matchedWord ?? "",
    wordIndex: extra?.wordIndex ?? null,
    createdAt: new Date().toISOString(),
  };
}

export function clampAyah(surahId: number, ayah: number): number {
  const s = SURAH_BY_ID[surahId];
  const max = s?.ayahs ?? 1;
  return Math.min(max, Math.max(1, ayah));
}

export { sessionItqan };
