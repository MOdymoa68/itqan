export type SurahMeta = {
  id: number;
  name: string;
  latin: string;
  ayahs: number;
  meccan: boolean;
};

export const SURAHS: SurahMeta[] = [
  { id: 1, name: 'الفاتحة', latin: 'Al-Fatihah', ayahs: 7, meccan: true },
  { id: 2, name: 'البقرة', latin: 'Al-Baqarah', ayahs: 286, meccan: false },
  { id: 3, name: 'آل عمران', latin: 'Ali \'Imran', ayahs: 200, meccan: false },
  { id: 4, name: 'النساء', latin: 'An-Nisa', ayahs: 176, meccan: false },
  { id: 5, name: 'المائدة', latin: 'Al-Ma\'idah', ayahs: 120, meccan: false },
  { id: 6, name: 'الأنعام', latin: 'Al-An\'am', ayahs: 165, meccan: true },
  { id: 7, name: 'الأعراف', latin: 'Al-A\'raf', ayahs: 206, meccan: true },
  { id: 8, name: 'الأنفال', latin: 'Al-Anfal', ayahs: 75, meccan: false },
  { id: 9, name: 'التوبة', latin: 'At-Tawbah', ayahs: 129, meccan: false },
  { id: 10, name: 'يونس', latin: 'Yunus', ayahs: 109, meccan: true },
  { id: 11, name: 'هود', latin: 'Hud', ayahs: 123, meccan: true },
  { id: 12, name: 'يوسف', latin: 'Yusuf', ayahs: 111, meccan: true },
  { id: 13, name: 'الرعد', latin: 'Ar-Ra\'d', ayahs: 43, meccan: false },
  { id: 14, name: 'ابراهيم', latin: 'Ibrahim', ayahs: 52, meccan: true },
  { id: 15, name: 'الحجر', latin: 'Al-Hijr', ayahs: 99, meccan: true },
  { id: 16, name: 'النحل', latin: 'An-Nahl', ayahs: 128, meccan: true },
  { id: 17, name: 'الإسراء', latin: 'Al-Isra', ayahs: 111, meccan: true },
  { id: 18, name: 'الكهف', latin: 'Al-Kahf', ayahs: 110, meccan: true },
  { id: 19, name: 'مريم', latin: 'Maryam', ayahs: 98, meccan: true },
  { id: 20, name: 'طه', latin: 'Taha', ayahs: 135, meccan: true },
  { id: 21, name: 'الأنبياء', latin: 'Al-Anbya', ayahs: 112, meccan: true },
  { id: 22, name: 'الحج', latin: 'Al-Hajj', ayahs: 78, meccan: false },
  { id: 23, name: 'المؤمنون', latin: 'Al-Mu\'minun', ayahs: 118, meccan: true },
  { id: 24, name: 'النور', latin: 'An-Nur', ayahs: 64, meccan: false },
  { id: 25, name: 'الفرقان', latin: 'Al-Furqan', ayahs: 77, meccan: true },
  { id: 26, name: 'الشعراء', latin: 'Ash-Shu\'ara', ayahs: 227, meccan: true },
  { id: 27, name: 'النمل', latin: 'An-Naml', ayahs: 93, meccan: true },
  { id: 28, name: 'القصص', latin: 'Al-Qasas', ayahs: 88, meccan: true },
  { id: 29, name: 'العنكبوت', latin: 'Al-\'Ankabut', ayahs: 69, meccan: true },
  { id: 30, name: 'الروم', latin: 'Ar-Rum', ayahs: 60, meccan: true },
  { id: 31, name: 'لقمان', latin: 'Luqman', ayahs: 34, meccan: true },
  { id: 32, name: 'السجدة', latin: 'As-Sajdah', ayahs: 30, meccan: true },
  { id: 33, name: 'الأحزاب', latin: 'Al-Ahzab', ayahs: 73, meccan: false },
  { id: 34, name: 'سبإ', latin: 'Saba', ayahs: 54, meccan: true },
  { id: 35, name: 'فاطر', latin: 'Fatir', ayahs: 45, meccan: true },
  { id: 36, name: 'يس', latin: 'Ya-Sin', ayahs: 83, meccan: true },
  { id: 37, name: 'الصافات', latin: 'As-Saffat', ayahs: 182, meccan: true },
  { id: 38, name: 'ص', latin: 'Sad', ayahs: 88, meccan: true },
  { id: 39, name: 'الزمر', latin: 'Az-Zumar', ayahs: 75, meccan: true },
  { id: 40, name: 'غافر', latin: 'Ghafir', ayahs: 85, meccan: true },
  { id: 41, name: 'فصلت', latin: 'Fussilat', ayahs: 54, meccan: true },
  { id: 42, name: 'الشورى', latin: 'Ash-Shuraa', ayahs: 53, meccan: true },
  { id: 43, name: 'الزخرف', latin: 'Az-Zukhruf', ayahs: 89, meccan: true },
  { id: 44, name: 'الدخان', latin: 'Ad-Dukhan', ayahs: 59, meccan: true },
  { id: 45, name: 'الجاثية', latin: 'Al-Jathiyah', ayahs: 37, meccan: true },
  { id: 46, name: 'الأحقاف', latin: 'Al-Ahqaf', ayahs: 35, meccan: true },
  { id: 47, name: 'محمد', latin: 'Muhammad', ayahs: 38, meccan: false },
  { id: 48, name: 'الفتح', latin: 'Al-Fath', ayahs: 29, meccan: false },
  { id: 49, name: 'الحجرات', latin: 'Al-Hujurat', ayahs: 18, meccan: false },
  { id: 50, name: 'ق', latin: 'Qaf', ayahs: 45, meccan: true },
  { id: 51, name: 'الذاريات', latin: 'Adh-Dhariyat', ayahs: 60, meccan: true },
  { id: 52, name: 'الطور', latin: 'At-Tur', ayahs: 49, meccan: true },
  { id: 53, name: 'النجم', latin: 'An-Najm', ayahs: 62, meccan: true },
  { id: 54, name: 'القمر', latin: 'Al-Qamar', ayahs: 55, meccan: true },
  { id: 55, name: 'الرحمن', latin: 'Ar-Rahman', ayahs: 78, meccan: false },
  { id: 56, name: 'الواقعة', latin: 'Al-Waqi\'ah', ayahs: 96, meccan: true },
  { id: 57, name: 'الحديد', latin: 'Al-Hadid', ayahs: 29, meccan: false },
  { id: 58, name: 'المجادلة', latin: 'Al-Mujadila', ayahs: 22, meccan: false },
  { id: 59, name: 'الحشر', latin: 'Al-Hashr', ayahs: 24, meccan: false },
  { id: 60, name: 'الممتحنة', latin: 'Al-Mumtahanah', ayahs: 13, meccan: false },
  { id: 61, name: 'الصف', latin: 'As-Saf', ayahs: 14, meccan: false },
  { id: 62, name: 'الجمعة', latin: 'Al-Jumu\'ah', ayahs: 11, meccan: false },
  { id: 63, name: 'المنافقون', latin: 'Al-Munafiqun', ayahs: 11, meccan: false },
  { id: 64, name: 'التغابن', latin: 'At-Taghabun', ayahs: 18, meccan: false },
  { id: 65, name: 'الطلاق', latin: 'At-Talaq', ayahs: 12, meccan: false },
  { id: 66, name: 'التحريم', latin: 'At-Tahrim', ayahs: 12, meccan: false },
  { id: 67, name: 'الملك', latin: 'Al-Mulk', ayahs: 30, meccan: true },
  { id: 68, name: 'القلم', latin: 'Al-Qalam', ayahs: 52, meccan: true },
  { id: 69, name: 'الحاقة', latin: 'Al-Haqqah', ayahs: 52, meccan: true },
  { id: 70, name: 'المعارج', latin: 'Al-Ma\'arij', ayahs: 44, meccan: true },
  { id: 71, name: 'نوح', latin: 'Nuh', ayahs: 28, meccan: true },
  { id: 72, name: 'الجن', latin: 'Al-Jinn', ayahs: 28, meccan: true },
  { id: 73, name: 'المزمل', latin: 'Al-Muzzammil', ayahs: 20, meccan: true },
  { id: 74, name: 'المدثر', latin: 'Al-Muddaththir', ayahs: 56, meccan: true },
  { id: 75, name: 'القيامة', latin: 'Al-Qiyamah', ayahs: 40, meccan: true },
  { id: 76, name: 'الانسان', latin: 'Al-Insan', ayahs: 31, meccan: false },
  { id: 77, name: 'المرسلات', latin: 'Al-Mursalat', ayahs: 50, meccan: true },
  { id: 78, name: 'النبإ', latin: 'An-Naba', ayahs: 40, meccan: true },
  { id: 79, name: 'النازعات', latin: 'An-Nazi\'at', ayahs: 46, meccan: true },
  { id: 80, name: 'عبس', latin: '\'Abasa', ayahs: 42, meccan: true },
  { id: 81, name: 'التكوير', latin: 'At-Takwir', ayahs: 29, meccan: true },
  { id: 82, name: 'الإنفطار', latin: 'Al-Infitar', ayahs: 19, meccan: true },
  { id: 83, name: 'المطففين', latin: 'Al-Mutaffifin', ayahs: 36, meccan: true },
  { id: 84, name: 'الإنشقاق', latin: 'Al-Inshiqaq', ayahs: 25, meccan: true },
  { id: 85, name: 'البروج', latin: 'Al-Buruj', ayahs: 22, meccan: true },
  { id: 86, name: 'الطارق', latin: 'At-Tariq', ayahs: 17, meccan: true },
  { id: 87, name: 'الأعلى', latin: 'Al-A\'la', ayahs: 19, meccan: true },
  { id: 88, name: 'الغاشية', latin: 'Al-Ghashiyah', ayahs: 26, meccan: true },
  { id: 89, name: 'الفجر', latin: 'Al-Fajr', ayahs: 30, meccan: true },
  { id: 90, name: 'البلد', latin: 'Al-Balad', ayahs: 20, meccan: true },
  { id: 91, name: 'الشمس', latin: 'Ash-Shams', ayahs: 15, meccan: true },
  { id: 92, name: 'الليل', latin: 'Al-Layl', ayahs: 21, meccan: true },
  { id: 93, name: 'الضحى', latin: 'Ad-Duhaa', ayahs: 11, meccan: true },
  { id: 94, name: 'الشرح', latin: 'Ash-Sharh', ayahs: 8, meccan: true },
  { id: 95, name: 'التين', latin: 'At-Tin', ayahs: 8, meccan: true },
  { id: 96, name: 'العلق', latin: 'Al-\'Alaq', ayahs: 19, meccan: true },
  { id: 97, name: 'القدر', latin: 'Al-Qadr', ayahs: 5, meccan: true },
  { id: 98, name: 'البينة', latin: 'Al-Bayyinah', ayahs: 8, meccan: false },
  { id: 99, name: 'الزلزلة', latin: 'Az-Zalzalah', ayahs: 8, meccan: false },
  { id: 100, name: 'العاديات', latin: 'Al-\'Adiyat', ayahs: 11, meccan: true },
  { id: 101, name: 'القارعة', latin: 'Al-Qari\'ah', ayahs: 11, meccan: true },
  { id: 102, name: 'التكاثر', latin: 'At-Takathur', ayahs: 8, meccan: true },
  { id: 103, name: 'العصر', latin: 'Al-\'Asr', ayahs: 3, meccan: true },
  { id: 104, name: 'الهمزة', latin: 'Al-Humazah', ayahs: 9, meccan: true },
  { id: 105, name: 'الفيل', latin: 'Al-Fil', ayahs: 5, meccan: true },
  { id: 106, name: 'قريش', latin: 'Quraysh', ayahs: 4, meccan: true },
  { id: 107, name: 'الماعون', latin: 'Al-Ma\'un', ayahs: 7, meccan: true },
  { id: 108, name: 'الكوثر', latin: 'Al-Kawthar', ayahs: 3, meccan: true },
  { id: 109, name: 'الكافرون', latin: 'Al-Kafirun', ayahs: 6, meccan: true },
  { id: 110, name: 'النصر', latin: 'An-Nasr', ayahs: 3, meccan: false },
  { id: 111, name: 'المسد', latin: 'Al-Masad', ayahs: 5, meccan: true },
  { id: 112, name: 'الإخلاص', latin: 'Al-Ikhlas', ayahs: 4, meccan: true },
  { id: 113, name: 'الفلق', latin: 'Al-Falaq', ayahs: 5, meccan: true },
  { id: 114, name: 'الناس', latin: 'An-Nas', ayahs: 6, meccan: true },
];

export const SURAH_BY_ID: Record<number, SurahMeta> = Object.fromEntries(
  SURAHS.map((s) => [s.id, s]),
);

export function surahLabel(id: number): string {
  const s = SURAH_BY_ID[id];
  return s ? `${s.id}. ${s.name}` : `سورة ${id}`;
}

export function rangeLabel(fromSurah: number, toSurah: number, fromAyah?: number, toAyah?: number): string {
  const a = SURAH_BY_ID[fromSurah];
  const b = SURAH_BY_ID[toSurah];
  const aName = a?.name ?? String(fromSurah);
  const bName = b?.name ?? String(toSurah);
  if (fromSurah === toSurah) {
    if (fromAyah && toAyah && (fromAyah !== 1 || toAyah !== (a?.ayahs ?? toAyah))) {
      return `${aName} · ${fromAyah}–${toAyah}`;
    }
    return aName;
  }
  return `${aName} → ${bName}`;
}

export function countAyahsInRange(fromSurah: number, toSurah: number, fromAyah = 1, toAyah?: number): number {
  const start = Math.min(fromSurah, toSurah);
  const end = Math.max(fromSurah, toSurah);
  let n = 0;
  for (let id = start; id <= end; id++) {
    const s = SURAH_BY_ID[id];
    if (!s) continue;
    const first = id === start ? fromAyah : 1;
    const last = id === end ? (toAyah ?? s.ayahs) : s.ayahs;
    n += Math.max(0, last - first + 1);
  }
  return n;
}
