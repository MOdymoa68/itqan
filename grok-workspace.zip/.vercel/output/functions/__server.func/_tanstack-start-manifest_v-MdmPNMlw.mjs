//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-MdmPNMlw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/history",
			"/report",
			"/schedule",
			"/stats",
			"/recite/$type"
		],
		preloads: ["/assets/index-9pR0Si2o.js", "/assets/store-BMt0ufWH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-9pR0Si2o.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D6QzEsjr.js", "/assets/badge-ozKnFjo9.js"]
	},
	"/history": {
		filePath: "/workspace/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-2Pq4Iho-.js",
			"/assets/trash-2-CjIq6dpA.js",
			"/assets/badge-ozKnFjo9.js"
		]
	},
	"/report": {
		filePath: "/workspace/src/routes/report.tsx",
		children: void 0,
		preloads: [
			"/assets/report-yVP1Hu8E.js",
			"/assets/badge-ozKnFjo9.js",
			"/assets/report-DeaVvW8y.js"
		]
	},
	"/schedule": {
		filePath: "/workspace/src/routes/schedule.tsx",
		children: void 0,
		preloads: ["/assets/schedule-H60d61vD.js", "/assets/surah-picker-DsLpe-ER.js"]
	},
	"/stats": {
		filePath: "/workspace/src/routes/stats.tsx",
		children: void 0,
		preloads: [
			"/assets/stats-D8QlXDm4.js",
			"/assets/badge-ozKnFjo9.js",
			"/assets/report-DeaVvW8y.js"
		]
	},
	"/recite/$type": {
		filePath: "/workspace/src/routes/recite.$type.tsx",
		children: void 0,
		preloads: [
			"/assets/recite._type-uJmdDD9w.js",
			"/assets/surah-picker-DsLpe-ER.js",
			"/assets/trash-2-CjIq6dpA.js",
			"/assets/badge-ozKnFjo9.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
