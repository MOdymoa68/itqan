import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as sessionItqan, r as countByKind, t as Badge } from "./badge-FGECkbyy.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronDown, a as Trash2, m as FileDown } from "../_libs/lucide-react.mjs";
import { C as cn, M as useItqanStore, O as rangeLabel, T as formatArDate, d as SESSION_LABEL, g as CardContent, h as Card, j as useActiveProfile, m as Button, u as ERROR_LABEL, y as SURAH_BY_ID } from "./router-B38-chNx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-C_mF_nrb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HistoryPage() {
	const profile = useActiveProfile();
	const sessions = useItqanStore((s) => profile ? s.sessions.filter((x) => x.profileId === profile.id) : []);
	const deleteSession = useItqanStore((s) => s.deleteSession);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const grouped = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const s of sessions) {
			const list = map.get(s.date) ?? [];
			list.push(s);
			map.set(s.date, list);
		}
		return [...map.entries()];
	}, [sessions]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "السجل"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "كل جلسة تسميع، أخطاؤها، ونسبة الإتقان."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/report",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "size-4" }), "تقرير"]
				})
			})]
		}), grouped.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "py-12 text-center text-sm text-muted-foreground",
			children: "السجل فارغ حتى تُنهي أول تسميع."
		}) }) : grouped.map(([date, list]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-muted-foreground",
				children: formatArDate(date)
			}), list.map((s) => {
				const counts = countByKind(s.errors);
				const open = openId === s.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rounded-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-center gap-3 text-right",
							onClick: () => setOpenId(open ? null : s.id),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-sm font-semibold",
										children: [
											SESSION_LABEL[s.type],
											" ·",
											" ",
											rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-1 flex flex-wrap gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												variant: "stop",
												children: [counts.stop, " أخطاء"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												variant: "lahn",
												children: [counts.lahn, " لحون"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												variant: "note",
												children: [counts.note, " تنبيهات"]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-display text-2xl text-primary tabular-nums",
									children: [sessionItqan(s), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 text-muted-foreground transition-transform", open && "rotate-180") })
							]
						}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-2 border-t border-border pt-3",
							children: [s.errors.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "جلسة بلا أخطاء مسجّلة."
							}) : s.errors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/70 px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: e.kind,
											children: ERROR_LABEL[e.kind]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-lg",
											children: e.matchedWord || e.word || "—"
										})]
									}),
									e.ayahText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-display text-base leading-loose",
										children: e.ayahText
									}) : null,
									e.ayahNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											SURAH_BY_ID[e.surahId ?? 0]?.name,
											" · آية ",
											e.ayahNumber
										]
									}) : null
								]
							}, e.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "sm",
								className: "justify-start text-destructive",
								onClick: () => deleteSession(s.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "حذف الجلسة"]
							})]
						}) : null]
					})
				}, s.id);
			})]
		}, date))]
	});
}
//#endregion
export { HistoryPage as component };
