import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as sessionItqan, n as averageItqan, r as countByKind, t as Badge } from "./badge-FGECkbyy.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as useItqanStore, O as rangeLabel, d as SESSION_LABEL, g as CardContent, h as Card, j as useActiveProfile, m as Button, u as ERROR_LABEL } from "./router-B38-chNx.mjs";
import { n as repeatedWords } from "./report-n5j0yf_o.mjs";
import { a as Bar, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stats-D6UPe4QB.js
var import_jsx_runtime = require_jsx_runtime();
function StatsPage() {
	const profile = useActiveProfile();
	const sessions = useItqanStore((s) => profile ? s.sessions.filter((x) => x.profileId === profile.id && x.completed) : []);
	const totals = countByKind(sessions.flatMap((s) => s.errors));
	const avg = averageItqan(sessions);
	const weakWords = repeatedWords(sessions, 2).slice(0, 12);
	const ayahMap = /* @__PURE__ */ new Map();
	for (const s of sessions) for (const e of s.errors) {
		if (!e.surahId || !e.ayahNumber) continue;
		const key = `${e.surahId}:${e.ayahNumber}`;
		const prev = ayahMap.get(key);
		ayahMap.set(key, {
			label: `${rangeLabel(e.surahId, e.surahId)} ${e.ayahNumber}`,
			count: (prev?.count ?? 0) + 1
		});
	}
	const weakAyahs = [...ayahMap.values()].filter((x) => x.count >= 2).sort((a, b) => b.count - a.count).slice(0, 8);
	const byType = [
		"hifz",
		"rabt",
		"murajaa"
	].map((t) => {
		const list = sessions.filter((s) => s.type === t);
		return {
			name: SESSION_LABEL[t],
			إتقان: list.length ? Math.round(list.reduce((n, s) => n + sessionItqan(s), 0) / list.length) : 0,
			جلسات: list.length
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold",
					children: "الإحصاء"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "نقاط الضعف المتكررة ومعدّل الإتقان عبر أنواع التسميع."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/report",
						children: "تصدير تقرير"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-muted-foreground",
						children: "متوسط الإتقان"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl text-primary tabular-nums",
						children: avg == null ? "—" : `${avg}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [sessions.length, " جلسة"]
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "grid gap-1.5",
					children: [
						["stop", totals.stop],
						["lahn", totals.lahn],
						["note", totals.note]
					].map(([k, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ERROR_LABEL[k] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums font-medium",
							children: n
						})]
					}, k))
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm font-medium",
				children: "الإتقان حسب النوع"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-52",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: byType,
						barSize: 28,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "var(--color-border)",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "name",
								tick: {
									fill: "var(--color-muted-foreground)",
									fontSize: 12
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								domain: [0, 100],
								tick: {
									fill: "var(--color-muted-foreground)",
									fontSize: 12
								},
								orientation: "right"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								cursor: { fill: "var(--color-muted)" },
								contentStyle: {
									background: "var(--color-card)",
									border: "1px solid var(--color-border)",
									borderRadius: 12,
									direction: "rtl"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "إتقان",
								fill: "var(--color-primary)",
								radius: [
									8,
									8,
									0,
									0
								]
							})
						]
					})
				})
			})] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "كلمات تكرر فيها الخطأ"
				}), weakWords.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "ستظهر هنا الكلمات التي أخطأت فيها أكثر من مرة."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: weakWords.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between rounded-lg bg-muted/70 px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl",
							children: w.word
						}), w.ayah ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 text-xs text-muted-foreground",
							children: w.ayah
						}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "stop",
							children: [w.count, "×"]
						})]
					}, w.word))
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "آيات متكررة الخطأ"
				}), weakAyahs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "لا آيات متكررة حتى الآن."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: weakAyahs.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums font-medium",
							children: a.count
						})]
					}, a.label))
				})]
			}) })
		]
	});
}
//#endregion
export { StatsPage as component };
