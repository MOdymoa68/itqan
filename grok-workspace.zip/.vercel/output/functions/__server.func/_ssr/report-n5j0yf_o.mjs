import { i as sessionItqan, n as averageItqan, r as countByKind } from "./badge-FGECkbyy.mjs";
import { A as todayISO, O as rangeLabel, T as formatArDate, b as WEEKDAYS_AR, c as CIRCLE_NAME, d as SESSION_LABEL, k as startOfWeekSunday, s as APP_NAME$1, u as ERROR_LABEL, x as addDays } from "./router-B38-chNx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/report-n5j0yf_o.js
function repeatedWords(sessions, min = 2) {
	const map = /* @__PURE__ */ new Map();
	for (const s of sessions) for (const e of s.errors) {
		const key = (e.matchedWord || e.word).trim();
		if (!key) continue;
		const prev = map.get(key);
		const ayah = e.surahId && e.ayahNumber ? `${rangeLabel(e.surahId, e.surahId)} ${e.ayahNumber}` : prev?.ayah ?? "";
		map.set(key, {
			word: key,
			count: (prev?.count ?? 0) + 1,
			ayah
		});
	}
	return [...map.values()].filter((x) => x.count >= min).sort((a, b) => b.count - a.count);
}
function weekSessions(sessions, weekStart) {
	const start = todayISO(weekStart);
	const end = todayISO(addDays(weekStart, 6));
	return sessions.filter((s) => s.date >= start && s.date <= end && s.completed);
}
async function downloadWeeklyPng(profile, sessions) {
	const weekStart = startOfWeekSunday();
	const week = weekSessions(sessions, weekStart);
	const counts = countByKind(week.flatMap((s) => s.errors));
	const avg = averageItqan(week);
	const weak = repeatedWords(week, 2).slice(0, 6);
	const end = addDays(weekStart, 4);
	const W = 1080;
	const H = 1520;
	const canvas = document.createElement("canvas");
	canvas.width = W;
	canvas.height = H;
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	await document.fonts.ready;
	ctx.fillStyle = "#f3eee4";
	ctx.fillRect(0, 0, W, H);
	ctx.fillStyle = "#1e4d3a";
	ctx.fillRect(0, 0, W, 220);
	ctx.fillStyle = "#f4efe6";
	ctx.textAlign = "right";
	ctx.direction = "rtl";
	ctx.font = "700 64px Amiri, serif";
	ctx.fillText(APP_NAME$1, 1008, 100);
	ctx.font = "500 28px 'IBM Plex Sans Arabic', sans-serif";
	ctx.fillText(CIRCLE_NAME, 1008, 150);
	ctx.font = "400 22px 'IBM Plex Sans Arabic', sans-serif";
	ctx.fillStyle = "#c9d7cf";
	ctx.fillText("تقرير الإنجاز الأسبوعي", 1008, 190);
	const box = (x, y, w, h) => {
		ctx.fillStyle = "#faf7f0";
		ctx.strokeStyle = "#e0d6c6";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.roundRect(x, y, w, h, 28);
		ctx.fill();
		ctx.stroke();
	};
	ctx.fillStyle = "#1c1915";
	ctx.font = "600 30px 'IBM Plex Sans Arabic', sans-serif";
	ctx.fillText(profile.name, 1008, 280);
	ctx.font = "400 22px 'IBM Plex Sans Arabic', sans-serif";
	ctx.fillStyle = "#6b6459";
	ctx.fillText(`${formatArDate(todayISO(weekStart))}  —  ${formatArDate(todayISO(end))}`, 1008, 318);
	[
		{
			label: "نسبة الإتقان",
			value: avg == null ? "—" : `${avg}%`
		},
		{
			label: "جلسات الأسبوع",
			value: String(week.length)
		},
		{
			label: ERROR_LABEL.stop,
			value: String(counts.stop)
		},
		{
			label: ERROR_LABEL.lahn,
			value: String(counts.lahn)
		},
		{
			label: ERROR_LABEL.note,
			value: String(counts.note)
		}
	].forEach((c, i) => {
		const x = 48 + i % 5 * 200;
		box(x, 360, 184, 140);
		ctx.textAlign = "center";
		ctx.fillStyle = "#1e4d3a";
		ctx.font = "700 40px 'IBM Plex Sans Arabic', sans-serif";
		ctx.fillText(c.value, x + 92, 432);
		ctx.fillStyle = "#6b6459";
		ctx.font = "500 18px 'IBM Plex Sans Arabic', sans-serif";
		ctx.fillText(c.label, x + 92, 470);
	});
	ctx.textAlign = "right";
	ctx.fillStyle = "#1c1915";
	ctx.font = "700 28px 'IBM Plex Sans Arabic', sans-serif";
	ctx.fillText("التسميع اليومي", 1008, 560);
	for (let i = 0; i < 5; i++) {
		const date = addDays(weekStart, i);
		const iso = todayISO(date);
		const daySessions = week.filter((s) => s.date === iso);
		const y = 590 + i * 86;
		box(48, y, 984, 74);
		ctx.fillStyle = "#1c1915";
		ctx.font = "600 24px 'IBM Plex Sans Arabic', sans-serif";
		ctx.fillText(WEEKDAYS_AR[i], 1e3, y + 46);
		ctx.fillStyle = "#6b6459";
		ctx.font = "400 20px 'IBM Plex Sans Arabic', sans-serif";
		if (daySessions.length === 0) ctx.fillText("لم يُسجَّل تسميع", 80, y + 46);
		else {
			const bits = daySessions.map((s) => {
				const itq = sessionItqan(s);
				return `${SESSION_LABEL[s.type]} · ${rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)} · ${itq}%`;
			});
			ctx.fillText(bits.join("  |  "), 80, y + 46);
		}
	}
	ctx.fillStyle = "#1c1915";
	ctx.font = "700 28px 'IBM Plex Sans Arabic', sans-serif";
	ctx.textAlign = "right";
	ctx.fillText("مواضع تكرر فيها الخطأ", 1008, 1068);
	box(48, 1090, 984, 280);
	if (weak.length === 0) {
		ctx.fillStyle = "#6b6459";
		ctx.font = "400 22px 'IBM Plex Sans Arabic', sans-serif";
		ctx.fillText("لا توجد كلمات متكررة هذا الأسبوع.", 1e3, 1160);
	} else weak.forEach((w, i) => {
		const y = 1140 + i * 36;
		ctx.fillStyle = "#1c1915";
		ctx.font = "600 22px Amiri, serif";
		ctx.fillText(w.word, 1e3, y);
		ctx.fillStyle = "#9b3d32";
		ctx.font = "600 20px 'IBM Plex Sans Arabic', sans-serif";
		ctx.textAlign = "left";
		ctx.fillText(`${w.count}×`, 80, y);
		ctx.textAlign = "right";
	});
	ctx.fillStyle = "#8a8276";
	ctx.font = "400 18px 'IBM Plex Sans Arabic', sans-serif";
	ctx.textAlign = "center";
	ctx.fillText(`${APP_NAME$1} · ${CIRCLE_NAME}`, W / 2, 1472);
	const url = canvas.toDataURL("image/png");
	const a = document.createElement("a");
	a.href = url;
	a.download = `itqan-${profile.name}-${todayISO()}.png`;
	a.click();
}
//#endregion
export { repeatedWords as n, weekSessions as r, downloadWeeklyPng as t };
