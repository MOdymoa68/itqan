import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as sessionItqan, r as countByKind, t as Badge } from "./badge-FGECkbyy.mjs";
import { a as Trash2, d as Minus, o as Search, u as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as cn, D as makeError, M as useItqanStore, S as clampAyah, d as SESSION_LABEL, f as Label, g as CardContent, h as Card, l as ERROR_HINT, m as Button, n as Route, p as Input, u as ERROR_LABEL, y as SURAH_BY_ID } from "./router-B38-chNx.mjs";
import { i as splitWords, n as loadQuran, r as searchWord, t as SurahPicker } from "./surah-picker-BJPflxYs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recite._type-DOQ6F4gq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AyahView({ hit, className }) {
	const surah = SURAH_BY_ID[hit.surahId];
	const words = splitWords(hit.ayahText);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: cn("rounded-xl bg-muted/70 px-4 py-3", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
			className: "mb-2 text-xs font-medium text-muted-foreground",
			children: [
				surah?.name,
				" · آية ",
				hit.ayahNumber
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl leading-loose text-foreground",
			dir: "rtl",
			children: words.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [i > 0 ? " " : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: i === hit.wordIndex ? "ayah-mark" : void 0,
				children: w
			})] }, `${i}-${w}`))
		})]
	});
}
var KINDS = [
	"stop",
	"lahn",
	"note"
];
var kindStyle = {
	stop: "bg-stop-soft text-stop",
	lahn: "bg-lahn-soft text-lahn",
	note: "bg-note-soft text-note"
};
function SessionRecorder({ type }) {
	const isRange = type !== "hifz";
	const profileId = useItqanStore((s) => s.activeProfileId);
	const completeSession = useItqanStore((s) => s.completeSession);
	const [fromSurah, setFromSurah] = (0, import_react.useState)(1);
	const [toSurah, setToSurah] = (0, import_react.useState)(1);
	const [fromAyah, setFromAyah] = (0, import_react.useState)(1);
	const [toAyah, setToAyah] = (0, import_react.useState)(7);
	const [started, setStarted] = (0, import_react.useState)(false);
	const [kind, setKind] = (0, import_react.useState)("lahn");
	const [query, setQuery] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [quran, setQuran] = (0, import_react.useState)(null);
	const [doneScore, setDoneScore] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		loadQuran().then(setQuran);
	}, []);
	(0, import_react.useEffect)(() => {
		const s = SURAH_BY_ID[fromSurah];
		if (!s) return;
		setFromAyah(1);
		if (!isRange) {
			setToSurah(fromSurah);
			setToAyah(s.ayahs);
		}
	}, [fromSurah, isRange]);
	(0, import_react.useEffect)(() => {
		if (!isRange) return;
		const s = SURAH_BY_ID[toSurah];
		if (!s) return;
		setToAyah(s.ayahs);
	}, [toSurah, isRange]);
	(0, import_react.useEffect)(() => {
		if (!started || !quran || query.trim().length < 2) {
			setHits([]);
			return;
		}
		const t = window.setTimeout(() => {
			const result = searchWord(quran, query, {
				fromSurah,
				toSurah: isRange ? toSurah : fromSurah,
				fromAyah,
				toAyah: isRange ? toAyah : toAyah
			});
			setHits(result);
			setPicked(result[0] ?? null);
		}, 140);
		return () => window.clearTimeout(t);
	}, [
		query,
		quran,
		started,
		fromSurah,
		toSurah,
		fromAyah,
		toAyah,
		isRange
	]);
	const counts = (0, import_react.useMemo)(() => countByKind(errors), [errors]);
	function addDetailed() {
		const word = query.trim();
		if (!word && !picked) {
			toast("اكتب الكلمة أو زد العداد مباشرة");
			return;
		}
		const next = makeError(kind, {
			word,
			surahId: picked?.surahId ?? fromSurah,
			ayahNumber: picked?.ayahNumber ?? null,
			ayahText: picked?.ayahText ?? "",
			matchedWord: picked?.word ?? word,
			wordIndex: picked?.wordIndex ?? null
		});
		setErrors((e) => [next, ...e]);
		setQuery("");
		setHits([]);
		setPicked(null);
	}
	function bump(k, delta) {
		if (delta > 0) {
			setErrors((e) => [makeError(k), ...e]);
			setKind(k);
		} else setErrors((e) => {
			const idx = e.findIndex((x) => x.kind === k);
			if (idx === -1) return e;
			return e.filter((_, i) => i !== idx);
		});
	}
	function finish() {
		if (!profileId) return;
		const session = completeSession({
			profileId,
			type,
			fromSurah,
			toSurah: isRange ? toSurah : fromSurah,
			fromAyah,
			toAyah,
			errors
		});
		setDoneScore(sessionItqan(session));
		setStarted(false);
		setErrors([]);
		toast.success("أُغلق التسميع وحُفظ في السجل");
	}
	if (doneScore != null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "flex flex-col items-center gap-4 py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted-foreground",
				children: "نسبة الإتقان"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-6xl text-primary tabular-nums",
				children: [doneScore, "%"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-xs text-sm text-muted-foreground",
				children: doneScore >= 90 ? "إتقان عالٍ. ثبّت الموضع بمراجعة خفيفة." : doneScore >= 70 ? "جيد. راجع مواضع اللحن قبل الجلسة القادمة." : "ركّز على الكلمات المتكررة في صفحة الإحصاء."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setDoneScore(null),
				children: "تسميع جديد"
			})
		]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: SESSION_LABEL[type]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: type === "hifz" ? "حدد السورة المقررة، ثم سجّل مواضع الخطأ أثناء التسميع." : "حدد المدى من سورة إلى سورة، ثم وثّق الأخطاء واللحون والتنبيهات."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-4",
				children: [
					isRange ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurahPicker, {
							label: "من سورة",
							value: fromSurah,
							onChange: setFromSurah
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurahPicker, {
							label: "إلى سورة",
							value: toSurah,
							onChange: setToSurah
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurahPicker, {
						label: "السورة المقررة",
						value: fromSurah,
						onChange: setFromSurah
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "from-ayah",
								children: "من آية"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "from-ayah",
								type: "number",
								min: 1,
								value: fromAyah,
								onChange: (e) => setFromAyah(clampAyah(fromSurah, Number(e.target.value) || 1))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "to-ayah",
								children: "إلى آية"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "to-ayah",
								type: "number",
								min: 1,
								value: toAyah,
								onChange: (e) => setToAyah(clampAyah(isRange ? toSurah : fromSurah, Number(e.target.value) || 1))
							})]
						})]
					}),
					!started ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						onClick: () => {
							setStarted(true);
							setDoneScore(null);
						},
						children: "بدء التسميع"
					}) : null
				]
			}) }),
			started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "px-2 py-3 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-muted-foreground",
									children: ERROR_LABEL[k]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-3xl tabular-nums leading-none",
									children: counts[k]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex justify-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "icon",
										variant: "outline",
										className: "size-9 min-h-9 min-w-9",
										onClick: () => bump(k, -1),
										"aria-label": `إنقاص ${ERROR_LABEL[k]}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "icon",
										variant: "secondary",
										className: "size-9 min-h-9 min-w-9",
										onClick: () => bump(k, 1),
										"aria-label": `زيادة ${ERROR_LABEL[k]}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
									})]
								})
							]
						})
					}, k))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "تسجيل كلمة الخطأ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1 rounded-xl bg-muted p-1",
							children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setKind(k),
								className: cn("h-9 flex-1 rounded-lg text-xs font-medium transition-colors", kind === k ? kindStyle[k] : "text-muted-foreground"),
								children: ERROR_LABEL[k]
							}, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: ERROR_HINT[kind]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: "اكتب الكلمة كما نطقها الطالب",
								className: "pr-10",
								dir: "rtl"
							})]
						}),
						hits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-2",
							children: hits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPicked(h),
								className: cn("w-full rounded-xl border p-2 text-right transition-colors", picked?.surahId === h.surahId && picked.ayahNumber === h.ayahNumber && picked.wordIndex === h.wordIndex ? "border-primary bg-secondary" : "border-border bg-card hover:bg-muted"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AyahView, {
									hit: h,
									className: "bg-transparent p-1"
								})
							}) }, `${h.surahId}-${h.ayahNumber}-${h.wordIndex}`))
						}) : query.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "لم يُعثر على الكلمة في النطاق. يمكنك إضافتها يدويًا."
						}) : null,
						picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								"التصحيح:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-lg text-primary",
									children: picked.word
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: addDetailed,
							variant: "secondary",
							children: "إضافة الموضع"
						})
					]
				}) }),
				errors.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "سجل هذه الجلسة"
					}), errors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2 rounded-xl bg-muted/70 px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: e.kind,
									children: ERROR_LABEL[e.kind]
								}), e.matchedWord || e.word ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-lg",
									children: e.matchedWord || e.word
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: "بدون كلمة"
								})]
							}), e.ayahNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									SURAH_BY_ID[e.surahId ?? 0]?.name,
									" · آية ",
									e.ayahNumber
								]
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "icon",
							variant: "ghost",
							className: "size-9",
							onClick: () => setErrors((list) => list.filter((x) => x.id !== e.id)),
							"aria-label": "حذف",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					}, e.id))]
				}) }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: finish,
					children: "إنهاء الجلسة وحفظها"
				})
			] }) : null
		]
	});
}
function RecitePage() {
	const { type } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionRecorder, { type });
}
//#endregion
export { RecitePage as component };
