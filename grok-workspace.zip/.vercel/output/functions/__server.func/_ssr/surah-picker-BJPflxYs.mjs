import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { g as ChevronsUpDown } from "../_libs/lucide-react.mjs";
import { C as cn, a as DialogHeader, i as DialogContent, m as Button, o as DialogTitle, p as Input, r as Dialog, v as SURAHS, y as SURAH_BY_ID } from "./router-B38-chNx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/surah-picker-BJPflxYs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TASHKEEL_RE = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08E1\u08E3-\u08FF\u0640]/g;
function stripTashkeel(input) {
	return input.replace(TASHKEEL_RE, "");
}
function normalizeArabic(input) {
	return stripTashkeel(input).replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/ة/g, "ه").replace(/[^\u0621-\u063A\u0641-\u064A\s]/g, "").replace(/\s+/g, " ").trim();
}
function splitWords(ayah) {
	return ayah.trim().split(/\s+/).filter(Boolean);
}
var cache = null;
var pending = null;
function loadQuran() {
	if (cache) return Promise.resolve(cache);
	if (typeof window === "undefined") return Promise.resolve({
		surahs: SURAHS,
		verses: []
	});
	if (!pending) pending = fetch("/data/quran.json").then((r) => {
		if (!r.ok) throw new Error("quran fetch failed");
		return r.json();
	}).then((data) => {
		cache = data;
		return data;
	});
	return pending;
}
function searchWord(data, query, range, limit = 8) {
	const q = normalizeArabic(query);
	if (q.length < 2) return [];
	const qTokens = q.split(" ").filter(Boolean);
	const hits = [];
	const start = Math.min(range.fromSurah, range.toSurah);
	const end = Math.max(range.fromSurah, range.toSurah);
	for (let sid = start; sid <= end; sid++) {
		const verses = data.verses[sid - 1];
		if (!verses) continue;
		const first = sid === start ? range.fromAyah : 1;
		const last = sid === end ? range.toAyah : verses.length;
		for (let a = first; a <= last; a++) {
			const text = verses[a - 1];
			if (!text) continue;
			const words = splitWords(text);
			const norm = words.map(normalizeArabic);
			if (qTokens.length > 1) {
				const idx = norm.join(" ").indexOf(q);
				if (idx >= 0) {
					let cursor = 0;
					let wordIndex = 0;
					for (let i = 0; i < norm.length; i++) {
						if (cursor === idx || cursor < idx && cursor + norm[i].length >= idx) {
							wordIndex = i;
							break;
						}
						cursor += norm[i].length + 1;
					}
					hits.push({
						surahId: sid,
						ayahNumber: a,
						ayahText: text,
						wordIndex,
						word: words[wordIndex] ?? "",
						score: 90
					});
				}
			} else for (let i = 0; i < norm.length; i++) {
				const w = norm[i];
				if (!w) continue;
				let score = 0;
				if (w === q) score = 100;
				else if (w.startsWith(q)) score = 80 - Math.min(20, w.length - q.length);
				else if (w.includes(q)) score = 50;
				if (score > 0) hits.push({
					surahId: sid,
					ayahNumber: a,
					ayahText: text,
					wordIndex: i,
					word: words[i],
					score
				});
			}
			if (hits.length > 80) break;
		}
		if (hits.length > 80) break;
	}
	hits.sort((a, b) => b.score - a.score || a.surahId - b.surahId || a.ayahNumber - b.ayahNumber);
	const seen = /* @__PURE__ */ new Set();
	const unique = [];
	for (const h of hits) {
		const key = `${h.surahId}:${h.ayahNumber}:${h.wordIndex}`;
		if (seen.has(key)) continue;
		seen.add(key);
		unique.push(h);
		if (unique.length >= limit) break;
	}
	return unique;
}
function SurahPicker({ value, onChange, label, className }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const selected = SURAH_BY_ID[value];
	const filtered = (0, import_react.useMemo)(() => {
		const n = normalizeArabic(q);
		const num = Number(q);
		return SURAHS.filter((s) => {
			if (!q.trim()) return true;
			if (!Number.isNaN(num) && s.id === num) return true;
			return normalizeArabic(s.name).includes(n) || s.latin.toLowerCase().includes(q.toLowerCase()) || String(s.id).includes(q.trim());
		});
	}, [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid gap-1.5", className),
		children: [
			label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				className: "h-11 w-full justify-between font-normal",
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: selected ? `${selected.id}. ${selected.name}` : "اختر سورة" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "size-4 text-muted-foreground" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[80vh] overflow-hidden p-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
							className: "px-5 pt-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "اختيار السورة" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-5 pb-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								autoFocus: true,
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: "ابحث بالاسم أو الرقم"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-h-[50vh] overflow-y-auto px-2 pb-4",
							children: [filtered.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									onChange(s.id);
									setOpen(false);
									setQ("");
								},
								className: cn("flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-right text-sm hover:bg-muted", s.id === value && "bg-secondary text-secondary-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium",
									children: [
										s.id,
										". ",
										s.name
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [s.ayahs, " آية"]
								})]
							}, s.id)), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-3 py-8 text-center text-sm text-muted-foreground",
								children: "لا توجد نتائج"
							}) : null]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { splitWords as i, loadQuran as n, searchWord as r, SurahPicker as t };
