import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { G as redirect, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as CalendarDays, i as TriangleAlert, n as UserRound, p as House, r as UserPlus, s as ScrollText, t as X, u as Plus, x as BookOpen, y as ChartColumn } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { a as Root2, i as Portal2, n as Item2, o as Separator2, r as Label2, s as Trigger, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-BQpRaLyR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
function todayISO(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function startOfWeekSunday(d = /* @__PURE__ */ new Date()) {
	const copy = new Date(d.getFullYear(), d.getMonth(), d.getDate());
	copy.setDate(copy.getDate() - copy.getDay());
	copy.setHours(0, 0, 0, 0);
	return copy;
}
function addDays(d, n) {
	const copy = new Date(d);
	copy.setDate(copy.getDate() + n);
	return copy;
}
function formatArDate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	const date = new Date(y, (m ?? 1) - 1, d ?? 1);
	return new Intl.DateTimeFormat("ar-EG", {
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(date);
}
function formatHijri(d = /* @__PURE__ */ new Date()) {
	try {
		return new Intl.DateTimeFormat("ar-SA-u-ca-islamic", {
			day: "numeric",
			month: "long",
			year: "numeric"
		}).format(d);
	} catch {
		return new Intl.DateTimeFormat("ar-EG", {
			day: "numeric",
			month: "long",
			year: "numeric"
		}).format(d);
	}
}
var WEEKDAYS_AR = [
	"الأحد",
	"الاثنين",
	"الثلاثاء",
	"الأربعاء",
	"الخميس",
	"الجمعة",
	"السبت"
];
var STUDY_DAYS = [
	0,
	1,
	2,
	3,
	4
];
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[color,background-color,opacity] duration-quick ease-smooth-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-accent",
			secondary: "bg-secondary text-secondary-foreground hover:bg-muted",
			outline: "border border-border bg-card text-foreground hover:bg-muted",
			ghost: "text-foreground hover:bg-muted",
			destructive: "bg-destructive text-destructive-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 rounded-md px-3 text-xs",
			lg: "h-12 min-h-12 px-6",
			icon: "size-11 min-h-11 min-w-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-2xl border border-border bg-card text-card-foreground shadow-card", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("p-4", className),
		...props
	});
}
var SURAHS = [
	{
		id: 1,
		name: "الفاتحة",
		latin: "Al-Fatihah",
		ayahs: 7,
		meccan: true
	},
	{
		id: 2,
		name: "البقرة",
		latin: "Al-Baqarah",
		ayahs: 286,
		meccan: false
	},
	{
		id: 3,
		name: "آل عمران",
		latin: "Ali 'Imran",
		ayahs: 200,
		meccan: false
	},
	{
		id: 4,
		name: "النساء",
		latin: "An-Nisa",
		ayahs: 176,
		meccan: false
	},
	{
		id: 5,
		name: "المائدة",
		latin: "Al-Ma'idah",
		ayahs: 120,
		meccan: false
	},
	{
		id: 6,
		name: "الأنعام",
		latin: "Al-An'am",
		ayahs: 165,
		meccan: true
	},
	{
		id: 7,
		name: "الأعراف",
		latin: "Al-A'raf",
		ayahs: 206,
		meccan: true
	},
	{
		id: 8,
		name: "الأنفال",
		latin: "Al-Anfal",
		ayahs: 75,
		meccan: false
	},
	{
		id: 9,
		name: "التوبة",
		latin: "At-Tawbah",
		ayahs: 129,
		meccan: false
	},
	{
		id: 10,
		name: "يونس",
		latin: "Yunus",
		ayahs: 109,
		meccan: true
	},
	{
		id: 11,
		name: "هود",
		latin: "Hud",
		ayahs: 123,
		meccan: true
	},
	{
		id: 12,
		name: "يوسف",
		latin: "Yusuf",
		ayahs: 111,
		meccan: true
	},
	{
		id: 13,
		name: "الرعد",
		latin: "Ar-Ra'd",
		ayahs: 43,
		meccan: false
	},
	{
		id: 14,
		name: "ابراهيم",
		latin: "Ibrahim",
		ayahs: 52,
		meccan: true
	},
	{
		id: 15,
		name: "الحجر",
		latin: "Al-Hijr",
		ayahs: 99,
		meccan: true
	},
	{
		id: 16,
		name: "النحل",
		latin: "An-Nahl",
		ayahs: 128,
		meccan: true
	},
	{
		id: 17,
		name: "الإسراء",
		latin: "Al-Isra",
		ayahs: 111,
		meccan: true
	},
	{
		id: 18,
		name: "الكهف",
		latin: "Al-Kahf",
		ayahs: 110,
		meccan: true
	},
	{
		id: 19,
		name: "مريم",
		latin: "Maryam",
		ayahs: 98,
		meccan: true
	},
	{
		id: 20,
		name: "طه",
		latin: "Taha",
		ayahs: 135,
		meccan: true
	},
	{
		id: 21,
		name: "الأنبياء",
		latin: "Al-Anbya",
		ayahs: 112,
		meccan: true
	},
	{
		id: 22,
		name: "الحج",
		latin: "Al-Hajj",
		ayahs: 78,
		meccan: false
	},
	{
		id: 23,
		name: "المؤمنون",
		latin: "Al-Mu'minun",
		ayahs: 118,
		meccan: true
	},
	{
		id: 24,
		name: "النور",
		latin: "An-Nur",
		ayahs: 64,
		meccan: false
	},
	{
		id: 25,
		name: "الفرقان",
		latin: "Al-Furqan",
		ayahs: 77,
		meccan: true
	},
	{
		id: 26,
		name: "الشعراء",
		latin: "Ash-Shu'ara",
		ayahs: 227,
		meccan: true
	},
	{
		id: 27,
		name: "النمل",
		latin: "An-Naml",
		ayahs: 93,
		meccan: true
	},
	{
		id: 28,
		name: "القصص",
		latin: "Al-Qasas",
		ayahs: 88,
		meccan: true
	},
	{
		id: 29,
		name: "العنكبوت",
		latin: "Al-'Ankabut",
		ayahs: 69,
		meccan: true
	},
	{
		id: 30,
		name: "الروم",
		latin: "Ar-Rum",
		ayahs: 60,
		meccan: true
	},
	{
		id: 31,
		name: "لقمان",
		latin: "Luqman",
		ayahs: 34,
		meccan: true
	},
	{
		id: 32,
		name: "السجدة",
		latin: "As-Sajdah",
		ayahs: 30,
		meccan: true
	},
	{
		id: 33,
		name: "الأحزاب",
		latin: "Al-Ahzab",
		ayahs: 73,
		meccan: false
	},
	{
		id: 34,
		name: "سبإ",
		latin: "Saba",
		ayahs: 54,
		meccan: true
	},
	{
		id: 35,
		name: "فاطر",
		latin: "Fatir",
		ayahs: 45,
		meccan: true
	},
	{
		id: 36,
		name: "يس",
		latin: "Ya-Sin",
		ayahs: 83,
		meccan: true
	},
	{
		id: 37,
		name: "الصافات",
		latin: "As-Saffat",
		ayahs: 182,
		meccan: true
	},
	{
		id: 38,
		name: "ص",
		latin: "Sad",
		ayahs: 88,
		meccan: true
	},
	{
		id: 39,
		name: "الزمر",
		latin: "Az-Zumar",
		ayahs: 75,
		meccan: true
	},
	{
		id: 40,
		name: "غافر",
		latin: "Ghafir",
		ayahs: 85,
		meccan: true
	},
	{
		id: 41,
		name: "فصلت",
		latin: "Fussilat",
		ayahs: 54,
		meccan: true
	},
	{
		id: 42,
		name: "الشورى",
		latin: "Ash-Shuraa",
		ayahs: 53,
		meccan: true
	},
	{
		id: 43,
		name: "الزخرف",
		latin: "Az-Zukhruf",
		ayahs: 89,
		meccan: true
	},
	{
		id: 44,
		name: "الدخان",
		latin: "Ad-Dukhan",
		ayahs: 59,
		meccan: true
	},
	{
		id: 45,
		name: "الجاثية",
		latin: "Al-Jathiyah",
		ayahs: 37,
		meccan: true
	},
	{
		id: 46,
		name: "الأحقاف",
		latin: "Al-Ahqaf",
		ayahs: 35,
		meccan: true
	},
	{
		id: 47,
		name: "محمد",
		latin: "Muhammad",
		ayahs: 38,
		meccan: false
	},
	{
		id: 48,
		name: "الفتح",
		latin: "Al-Fath",
		ayahs: 29,
		meccan: false
	},
	{
		id: 49,
		name: "الحجرات",
		latin: "Al-Hujurat",
		ayahs: 18,
		meccan: false
	},
	{
		id: 50,
		name: "ق",
		latin: "Qaf",
		ayahs: 45,
		meccan: true
	},
	{
		id: 51,
		name: "الذاريات",
		latin: "Adh-Dhariyat",
		ayahs: 60,
		meccan: true
	},
	{
		id: 52,
		name: "الطور",
		latin: "At-Tur",
		ayahs: 49,
		meccan: true
	},
	{
		id: 53,
		name: "النجم",
		latin: "An-Najm",
		ayahs: 62,
		meccan: true
	},
	{
		id: 54,
		name: "القمر",
		latin: "Al-Qamar",
		ayahs: 55,
		meccan: true
	},
	{
		id: 55,
		name: "الرحمن",
		latin: "Ar-Rahman",
		ayahs: 78,
		meccan: false
	},
	{
		id: 56,
		name: "الواقعة",
		latin: "Al-Waqi'ah",
		ayahs: 96,
		meccan: true
	},
	{
		id: 57,
		name: "الحديد",
		latin: "Al-Hadid",
		ayahs: 29,
		meccan: false
	},
	{
		id: 58,
		name: "المجادلة",
		latin: "Al-Mujadila",
		ayahs: 22,
		meccan: false
	},
	{
		id: 59,
		name: "الحشر",
		latin: "Al-Hashr",
		ayahs: 24,
		meccan: false
	},
	{
		id: 60,
		name: "الممتحنة",
		latin: "Al-Mumtahanah",
		ayahs: 13,
		meccan: false
	},
	{
		id: 61,
		name: "الصف",
		latin: "As-Saf",
		ayahs: 14,
		meccan: false
	},
	{
		id: 62,
		name: "الجمعة",
		latin: "Al-Jumu'ah",
		ayahs: 11,
		meccan: false
	},
	{
		id: 63,
		name: "المنافقون",
		latin: "Al-Munafiqun",
		ayahs: 11,
		meccan: false
	},
	{
		id: 64,
		name: "التغابن",
		latin: "At-Taghabun",
		ayahs: 18,
		meccan: false
	},
	{
		id: 65,
		name: "الطلاق",
		latin: "At-Talaq",
		ayahs: 12,
		meccan: false
	},
	{
		id: 66,
		name: "التحريم",
		latin: "At-Tahrim",
		ayahs: 12,
		meccan: false
	},
	{
		id: 67,
		name: "الملك",
		latin: "Al-Mulk",
		ayahs: 30,
		meccan: true
	},
	{
		id: 68,
		name: "القلم",
		latin: "Al-Qalam",
		ayahs: 52,
		meccan: true
	},
	{
		id: 69,
		name: "الحاقة",
		latin: "Al-Haqqah",
		ayahs: 52,
		meccan: true
	},
	{
		id: 70,
		name: "المعارج",
		latin: "Al-Ma'arij",
		ayahs: 44,
		meccan: true
	},
	{
		id: 71,
		name: "نوح",
		latin: "Nuh",
		ayahs: 28,
		meccan: true
	},
	{
		id: 72,
		name: "الجن",
		latin: "Al-Jinn",
		ayahs: 28,
		meccan: true
	},
	{
		id: 73,
		name: "المزمل",
		latin: "Al-Muzzammil",
		ayahs: 20,
		meccan: true
	},
	{
		id: 74,
		name: "المدثر",
		latin: "Al-Muddaththir",
		ayahs: 56,
		meccan: true
	},
	{
		id: 75,
		name: "القيامة",
		latin: "Al-Qiyamah",
		ayahs: 40,
		meccan: true
	},
	{
		id: 76,
		name: "الانسان",
		latin: "Al-Insan",
		ayahs: 31,
		meccan: false
	},
	{
		id: 77,
		name: "المرسلات",
		latin: "Al-Mursalat",
		ayahs: 50,
		meccan: true
	},
	{
		id: 78,
		name: "النبإ",
		latin: "An-Naba",
		ayahs: 40,
		meccan: true
	},
	{
		id: 79,
		name: "النازعات",
		latin: "An-Nazi'at",
		ayahs: 46,
		meccan: true
	},
	{
		id: 80,
		name: "عبس",
		latin: "'Abasa",
		ayahs: 42,
		meccan: true
	},
	{
		id: 81,
		name: "التكوير",
		latin: "At-Takwir",
		ayahs: 29,
		meccan: true
	},
	{
		id: 82,
		name: "الإنفطار",
		latin: "Al-Infitar",
		ayahs: 19,
		meccan: true
	},
	{
		id: 83,
		name: "المطففين",
		latin: "Al-Mutaffifin",
		ayahs: 36,
		meccan: true
	},
	{
		id: 84,
		name: "الإنشقاق",
		latin: "Al-Inshiqaq",
		ayahs: 25,
		meccan: true
	},
	{
		id: 85,
		name: "البروج",
		latin: "Al-Buruj",
		ayahs: 22,
		meccan: true
	},
	{
		id: 86,
		name: "الطارق",
		latin: "At-Tariq",
		ayahs: 17,
		meccan: true
	},
	{
		id: 87,
		name: "الأعلى",
		latin: "Al-A'la",
		ayahs: 19,
		meccan: true
	},
	{
		id: 88,
		name: "الغاشية",
		latin: "Al-Ghashiyah",
		ayahs: 26,
		meccan: true
	},
	{
		id: 89,
		name: "الفجر",
		latin: "Al-Fajr",
		ayahs: 30,
		meccan: true
	},
	{
		id: 90,
		name: "البلد",
		latin: "Al-Balad",
		ayahs: 20,
		meccan: true
	},
	{
		id: 91,
		name: "الشمس",
		latin: "Ash-Shams",
		ayahs: 15,
		meccan: true
	},
	{
		id: 92,
		name: "الليل",
		latin: "Al-Layl",
		ayahs: 21,
		meccan: true
	},
	{
		id: 93,
		name: "الضحى",
		latin: "Ad-Duhaa",
		ayahs: 11,
		meccan: true
	},
	{
		id: 94,
		name: "الشرح",
		latin: "Ash-Sharh",
		ayahs: 8,
		meccan: true
	},
	{
		id: 95,
		name: "التين",
		latin: "At-Tin",
		ayahs: 8,
		meccan: true
	},
	{
		id: 96,
		name: "العلق",
		latin: "Al-'Alaq",
		ayahs: 19,
		meccan: true
	},
	{
		id: 97,
		name: "القدر",
		latin: "Al-Qadr",
		ayahs: 5,
		meccan: true
	},
	{
		id: 98,
		name: "البينة",
		latin: "Al-Bayyinah",
		ayahs: 8,
		meccan: false
	},
	{
		id: 99,
		name: "الزلزلة",
		latin: "Az-Zalzalah",
		ayahs: 8,
		meccan: false
	},
	{
		id: 100,
		name: "العاديات",
		latin: "Al-'Adiyat",
		ayahs: 11,
		meccan: true
	},
	{
		id: 101,
		name: "القارعة",
		latin: "Al-Qari'ah",
		ayahs: 11,
		meccan: true
	},
	{
		id: 102,
		name: "التكاثر",
		latin: "At-Takathur",
		ayahs: 8,
		meccan: true
	},
	{
		id: 103,
		name: "العصر",
		latin: "Al-'Asr",
		ayahs: 3,
		meccan: true
	},
	{
		id: 104,
		name: "الهمزة",
		latin: "Al-Humazah",
		ayahs: 9,
		meccan: true
	},
	{
		id: 105,
		name: "الفيل",
		latin: "Al-Fil",
		ayahs: 5,
		meccan: true
	},
	{
		id: 106,
		name: "قريش",
		latin: "Quraysh",
		ayahs: 4,
		meccan: true
	},
	{
		id: 107,
		name: "الماعون",
		latin: "Al-Ma'un",
		ayahs: 7,
		meccan: true
	},
	{
		id: 108,
		name: "الكوثر",
		latin: "Al-Kawthar",
		ayahs: 3,
		meccan: true
	},
	{
		id: 109,
		name: "الكافرون",
		latin: "Al-Kafirun",
		ayahs: 6,
		meccan: true
	},
	{
		id: 110,
		name: "النصر",
		latin: "An-Nasr",
		ayahs: 3,
		meccan: false
	},
	{
		id: 111,
		name: "المسد",
		latin: "Al-Masad",
		ayahs: 5,
		meccan: true
	},
	{
		id: 112,
		name: "الإخلاص",
		latin: "Al-Ikhlas",
		ayahs: 4,
		meccan: true
	},
	{
		id: 113,
		name: "الفلق",
		latin: "Al-Falaq",
		ayahs: 5,
		meccan: true
	},
	{
		id: 114,
		name: "الناس",
		latin: "An-Nas",
		ayahs: 6,
		meccan: true
	}
];
var SURAH_BY_ID = Object.fromEntries(SURAHS.map((s) => [s.id, s]));
function rangeLabel(fromSurah, toSurah, fromAyah, toAyah) {
	const a = SURAH_BY_ID[fromSurah];
	const b = SURAH_BY_ID[toSurah];
	const aName = a?.name ?? String(fromSurah);
	const bName = b?.name ?? String(toSurah);
	if (fromSurah === toSurah) {
		if (fromAyah && toAyah && (fromAyah !== 1 || toAyah !== (a?.ayahs ?? toAyah))) return `${aName} · ${fromAyah}–${toAyah}`;
		return aName;
	}
	return `${aName} → ${bName}`;
}
function countAyahsInRange(fromSurah, toSurah, fromAyah = 1, toAyah) {
	const start = Math.min(fromSurah, toSurah);
	const end = Math.max(fromSurah, toSurah);
	let n = 0;
	for (let id = start; id <= end; id++) {
		const s = SURAH_BY_ID[id];
		if (!s) continue;
		const first = id === start ? fromAyah : 1;
		const last = id === end ? toAyah ?? s.ayahs : s.ayahs;
		n += Math.max(0, last - first + 1);
	}
	return n;
}
var TINTS = [
	152,
	28,
	200,
	84,
	340,
	48
];
var emptySchedule = () => ({ days: {
	0: null,
	1: null,
	2: null,
	3: null,
	4: null
} });
var useItqanStore = create()(persist((set, get) => ({
	profiles: [],
	activeProfileId: null,
	sessions: [],
	schedules: {},
	completions: {},
	hydrated: false,
	setHydrated: (v) => set({ hydrated: v }),
	addProfile: (name) => {
		const trimmed = name.trim();
		const id = uid();
		const tint = TINTS[get().profiles.length % TINTS.length];
		const profile = {
			id,
			name: trimmed || "طالب",
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			tint
		};
		set((s) => ({
			profiles: [...s.profiles, profile],
			activeProfileId: id,
			schedules: {
				...s.schedules,
				[id]: emptySchedule()
			}
		}));
		return id;
	},
	renameProfile: (id, name) => {
		const trimmed = name.trim();
		if (!trimmed) return;
		set((s) => ({ profiles: s.profiles.map((p) => p.id === id ? {
			...p,
			name: trimmed
		} : p) }));
	},
	deleteProfile: (id) => {
		set((s) => {
			const profiles = s.profiles.filter((p) => p.id !== id);
			const { [id]: _s, ...schedules } = s.schedules;
			const { [id]: _c, ...completions } = s.completions;
			return {
				profiles,
				schedules,
				completions,
				sessions: s.sessions.filter((sess) => sess.profileId !== id),
				activeProfileId: s.activeProfileId === id ? profiles[0]?.id ?? null : s.activeProfileId
			};
		});
	},
	setActiveProfile: (id) => set({ activeProfileId: id }),
	setDayPlan: (profileId, day, plan) => {
		set((s) => {
			const current = s.schedules[profileId] ?? emptySchedule();
			return { schedules: {
				...s.schedules,
				[profileId]: { days: {
					...current.days,
					[day]: plan
				} }
			} };
		});
	},
	toggleCompletion: (profileId, date) => {
		set((s) => {
			const map = s.completions[profileId] ?? {};
			return { completions: {
				...s.completions,
				[profileId]: {
					...map,
					[date]: !map[date]
				}
			} };
		});
	},
	markCompletion: (profileId, date, done) => {
		set((s) => {
			const map = s.completions[profileId] ?? {};
			return { completions: {
				...s.completions,
				[profileId]: {
					...map,
					[date]: done
				}
			} };
		});
	},
	completeSession: (input) => {
		const session = {
			id: uid(),
			profileId: input.profileId,
			type: input.type,
			date: todayISO(),
			fromSurah: input.fromSurah,
			toSurah: input.toSurah,
			fromAyah: input.fromAyah,
			toAyah: input.toAyah,
			errors: input.errors,
			completed: true,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			endedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({ sessions: [session, ...s.sessions] }));
		get().markCompletion(input.profileId, session.date, true);
		return session;
	},
	deleteSession: (id) => {
		set((s) => ({ sessions: s.sessions.filter((sess) => sess.id !== id) }));
	}
}), {
	name: "itqan-v1",
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	skipHydration: true,
	partialize: (s) => ({
		profiles: s.profiles,
		activeProfileId: s.activeProfileId,
		sessions: s.sessions,
		schedules: s.schedules,
		completions: s.completions
	})
}));
function useActiveProfile() {
	return useItqanStore((s) => s.profiles.find((p) => p.id === s.activeProfileId) ?? null);
}
function makeError(kind, extra) {
	return {
		id: uid(),
		kind,
		word: extra?.word ?? "",
		surahId: extra?.surahId ?? null,
		ayahNumber: extra?.ayahNumber ?? null,
		ayahText: extra?.ayahText ?? "",
		matchedWord: extra?.matchedWord ?? "",
		wordIndex: extra?.wordIndex ?? null,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function clampAyah(surahId, ayah) {
	const max = SURAH_BY_ID[surahId]?.ayahs ?? 1;
	return Math.min(max, Math.max(1, ayah));
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-B38-chNx.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Logo({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 48",
		fill: "none",
		"aria-hidden": "true",
		className: cn("size-9", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "48",
				height: "48",
				rx: "12",
				fill: "currentColor",
				className: "text-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 16.5c0-.8.6-1.5 1.4-1.5h9.2c.4 0 .8.2 1.1.5L28 20h6.6c.8 0 1.4.7 1.4 1.5v14c0 .8-.6 1.5-1.4 1.5H13.4c-.8 0-1.4-.7-1.4-1.5v-19Z",
				fill: "currentColor",
				className: "text-primary-foreground",
				opacity: "0.16"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M14 18h9l4 4h7v14H14V18Z",
				stroke: "currentColor",
				className: "text-primary-foreground",
				strokeWidth: "1.6",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M23 18v4h4",
				stroke: "currentColor",
				className: "text-primary-foreground",
				strokeWidth: "1.6",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 28.5h12M18 32.5h8",
				stroke: "currentColor",
				className: "text-primary-foreground",
				strokeWidth: "1.5",
				strokeLinecap: "round",
				opacity: "0.8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "24",
				cy: "24.5",
				r: "1.6",
				fill: "currentColor",
				className: "text-primary-foreground"
			})
		]
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-lg border border-input bg-card px-3 text-base text-foreground shadow-none transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-sm font-medium text-foreground", className),
	...props
}));
Label.displayName = Root.displayName;
var CIRCLE_NAME = "حلقة ربعي بن عمرو الأنصاري";
var APP_NAME$1 = "إتقان";
var SESSION_LABEL = {
	hifz: "حفظ جديد",
	rabt: "ربط",
	murajaa: "مراجعة"
};
var ERROR_LABEL = {
	stop: "أخطاء",
	lahn: "لحون",
	note: "تنبيهات"
};
var ERROR_HINT = {
	stop: "توقف أو نسيان كلمة",
	lahn: "لحن جلي أو خفي / تغيير حركة",
	note: "ترديد أو تردد"
};
function ProfileGate({ children }) {
	const profiles = useItqanStore((s) => s.profiles);
	const active = useItqanStore((s) => s.activeProfileId);
	const addProfile = useItqanStore((s) => s.addProfile);
	const setActive = useItqanStore((s) => s.setActiveProfile);
	const [name, setName] = (0, import_react.useState)("");
	if (active && profiles.some((p) => p.id === active)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	function submit(e) {
		e.preventDefault();
		if (!name.trim()) return;
		addProfile(name);
		setName("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-md flex-col justify-center gap-6 px-5 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "size-14" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-4xl text-primary",
					children: APP_NAME$1
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm font-medium text-muted-foreground",
					children: CIRCLE_NAME
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground",
					children: "رفيقك الفردي لتدوين أخطاء التسميع، وتصحيح الكلمة وفق رسم المصحف، ومتابعة نسبة الإتقان."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "grid gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "student-name",
						children: "اسم الطالب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "student-name",
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "مثال: عبدالله",
						autoComplete: "name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: !name.trim(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4" }), "إنشاء ملف على هذا الجهاز"]
					})
				]
			}), profiles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-muted-foreground",
					children: "الملفات الموجودة"
				}), profiles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setActive(p.id),
					className: "flex h-11 items-center justify-between rounded-lg bg-muted px-3 text-sm hover:bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "دخول"
					})]
				}, p.id))]
			}) : null]
		}) })]
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-foreground/40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 right-4 left-4 z-50 mx-auto grid max-w-md -translate-y-1/2 gap-4 rounded-2xl border border-border bg-popover p-5 text-popover-foreground shadow-card duration-fast data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-4 left-4 rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "إغلاق"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 text-right", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-lg font-semibold leading-snug", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-44 overflow-hidden rounded-xl border border-border bg-popover p-1 text-popover-foreground shadow-card data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2.5 text-sm outline-none select-none focus:bg-muted data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-border", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-3 py-2 text-xs font-medium text-muted-foreground", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var NAV = [
	{
		to: "/",
		label: "الرئيسية",
		icon: House,
		match: void 0,
		params: void 0
	},
	{
		to: "/recite/$type",
		label: "تسميع",
		icon: BookOpen,
		match: "/recite",
		params: { type: "hifz" }
	},
	{
		to: "/schedule",
		label: "الجدول",
		icon: CalendarDays,
		match: void 0,
		params: void 0
	},
	{
		to: "/history",
		label: "السجل",
		icon: ScrollText,
		match: void 0,
		params: void 0
	},
	{
		to: "/stats",
		label: "إحصاء",
		icon: ChartColumn,
		match: void 0,
		params: void 0
	}
];
function AppShell({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const profile = useActiveProfile();
	const profiles = useItqanStore((s) => s.profiles);
	const setActive = useItqanStore((s) => s.setActiveProfile);
	const addProfile = useItqanStore((s) => s.addProfile);
	const renameProfile = useItqanStore((s) => s.renameProfile);
	const deleteProfile = useItqanStore((s) => s.deleteProfile);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [newName, setNewName] = (0, import_react.useState)("");
	const [renameOpen, setRenameOpen] = (0, import_react.useState)(false);
	const [renameValue, setRenameValue] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		useItqanStore.persist.rehydrate().then(() => {
			useItqanStore.getState().setHydrated(true);
			setReady(true);
		});
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "size-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl text-primary",
			children: APP_NAME$1
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-frame min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-3xl items-center justify-between gap-3 px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "leading-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-xl leading-none text-primary",
								children: APP_NAME$1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block max-w-40 truncate text-xs text-muted-foreground",
								children: CIRCLE_NAME
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "max-w-40 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: profile?.name ?? "الملف"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "start",
						className: "w-56",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "ملفات هذا الجهاز" }),
							profiles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onSelect: () => setActive(p.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("flex-1", p.id === profile?.id && "font-semibold"),
									children: p.name
								}), p.id === profile?.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-primary",
									children: "الحالي"
								}) : null]
							}, p.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
								onSelect: () => {
									setRenameValue(profile?.name ?? "");
									setRenameOpen(true);
								},
								children: "إعادة تسمية"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onSelect: () => {
									setNewName("");
									setAddOpen(true);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "إضافة طالب"]
							}),
							profile && profiles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
								className: "text-destructive",
								onSelect: () => {
									deleteProfile(profile.id);
									toast("أُزيل الملف من هذا الجهاز");
								},
								children: "حذف الملف الحالي"
							}) : null
						]
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-3xl px-4 pt-5 pb-28",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-auto grid max-w-3xl grid-cols-5 px-1",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : item.match ? pathname.startsWith(item.match) : pathname === item.to;
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							params: item.params,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs font-medium", active ? "text-primary" : "text-muted-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.2 : 1.8
							}), item.label]
						}) }, item.label);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: addOpen,
				onOpenChange: setAddOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "طالب جديد" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "يُحفظ الملف على هذا الجهاز فقط، ويمكن التبديل في أي وقت." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: (e) => {
						e.preventDefault();
						if (!newName.trim()) return;
						addProfile(newName);
						setAddOpen(false);
						setNewName("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: newName,
						onChange: (e) => setNewName(e.target.value),
						placeholder: "اسم الطالب"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "إضافة"
					})]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: renameOpen,
				onOpenChange: setRenameOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "إعادة تسمية الملف" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: (e) => {
						e.preventDefault();
						if (!profile || !renameValue.trim()) return;
						renameProfile(profile.id, renameValue);
						setRenameOpen(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: renameValue,
						onChange: (e) => setRenameValue(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "حفظ"
					})]
				})] })
			})
		]
	}) });
}
var styles_default = "/assets/styles-B_-eQ4X7.css";
var APP_NAME = "إتقان";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "تطبيق إتقان لمتابعة وتصحيح الحفظ القرآني"
			},
			{
				name: "theme-color",
				content: "#1e4d3a"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: RootLayout
});
function RootLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				dir: "rtl",
				toastOptions: { className: "font-sans" }
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$5 = () => import("./routes-R-6T00Yq.mjs");
var Route$5 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./history-C_mF_nrb.mjs");
var Route$4 = createFileRoute("/history")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./report-DW7Srk2E.mjs");
var Route$3 = createFileRoute("/report")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./schedule-X65ngEc9.mjs");
var Route$2 = createFileRoute("/schedule")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./stats-D6UPe4QB.mjs");
var Route$1 = createFileRoute("/stats")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./recite._type-DOQ6F4gq.mjs");
var TYPES = [
	"hifz",
	"rabt",
	"murajaa"
];
var Route = createFileRoute("/recite/$type")({
	beforeLoad: ({ params }) => {
		if (!TYPES.includes(params.type)) throw redirect({
			to: "/recite/$type",
			params: { type: "hifz" }
		});
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	HistoryRoute: Route$4.update({
		id: "/history",
		path: "/history",
		getParentRoute: () => Route$6
	}),
	ReportRoute: Route$3.update({
		id: "/report",
		path: "/report",
		getParentRoute: () => Route$6
	}),
	ScheduleRoute: Route$2.update({
		id: "/schedule",
		path: "/schedule",
		getParentRoute: () => Route$6
	}),
	StatsRoute: Route$1.update({
		id: "/stats",
		path: "/stats",
		getParentRoute: () => Route$6
	}),
	ReciteTypeRoute: Route.update({
		id: "/recite/$type",
		path: "/recite/$type",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { todayISO as A, cn as C, makeError as D, formatHijri as E, useItqanStore as M, rangeLabel as O, clampAyah as S, formatArDate as T, STUDY_DAYS as _, DialogHeader as a, WEEKDAYS_AR as b, CIRCLE_NAME as c, SESSION_LABEL as d, Label as f, CardContent as g, Card as h, DialogContent as i, useActiveProfile as j, startOfWeekSunday as k, ERROR_HINT as l, Button as m, Route as n, DialogTitle as o, Input as p, Dialog as r, APP_NAME$1 as s, router_exports as t, ERROR_LABEL as u, SURAHS as v, countAyahsInRange as w, addDays as x, SURAH_BY_ID as y };
