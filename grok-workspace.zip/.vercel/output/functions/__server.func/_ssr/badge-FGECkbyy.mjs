import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { C as cn, w as countAyahsInRange } from "./router-B38-chNx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-FGECkbyy.js
var import_jsx_runtime = require_jsx_runtime();
var WEIGHT = {
	stop: 5,
	lahn: 3,
	note: 1
};
function countByKind(errors) {
	const out = {
		stop: 0,
		lahn: 0,
		note: 0
	};
	for (const e of errors) out[e.kind] += 1;
	return out;
}
function sessionItqan(session) {
	const ayahs = Math.max(1, countAyahsInRange(session.fromSurah, session.toSurah, session.fromAyah, session.toAyah));
	const score = 100 - session.errors.reduce((sum, e) => sum + WEIGHT[e.kind], 0) / ayahs * 12;
	return Math.max(0, Math.min(100, Math.round(score)));
}
function averageItqan(sessions) {
	const done = sessions.filter((s) => s.completed);
	if (done.length === 0) return null;
	const total = done.reduce((sum, s) => sum + sessionItqan(s), 0);
	return Math.round(total / done.length);
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "border-transparent bg-secondary text-secondary-foreground",
		outline: "border-border text-foreground",
		stop: "border-transparent bg-stop-soft text-stop",
		lahn: "border-transparent bg-lahn-soft text-lahn",
		note: "border-transparent bg-note-soft text-note"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { sessionItqan as i, averageItqan as n, countByKind as r, Badge as t };
