import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Check } from "../_libs/lucide-react.mjs";
import { A as todayISO, C as cn, M as useItqanStore, O as rangeLabel, S as clampAyah, _ as STUDY_DAYS, b as WEEKDAYS_AR, f as Label, g as CardContent, h as Card, j as useActiveProfile, k as startOfWeekSunday, m as Button, p as Input, x as addDays, y as SURAH_BY_ID } from "./router-B38-chNx.mjs";
import { t as SurahPicker } from "./surah-picker-BJPflxYs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schedule-X65ngEc9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function emptyPlan() {
	return {
		fromSurah: 1,
		toSurah: 1,
		fromAyah: 1,
		toAyah: 7
	};
}
function SchedulePage() {
	const profile = useActiveProfile();
	const schedule = useItqanStore((s) => profile ? s.schedules[profile.id] : void 0);
	const completions = useItqanStore((s) => profile ? s.completions[profile.id] : void 0);
	const setDayPlan = useItqanStore((s) => s.setDayPlan);
	const toggleCompletion = useItqanStore((s) => s.toggleCompletion);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(emptyPlan());
	if (!profile) return null;
	const weekStart = startOfWeekSunday();
	const todayDow = (/* @__PURE__ */ new Date()).getDay();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "الجدول الأسبوعي"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "نظّم مقدار التسميع من الأحد إلى الخميس. الجمعة والسبت للراحة."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: STUDY_DAYS.map((day) => {
					const date = addDays(weekStart, day);
					const iso = todayISO(date);
					const plan = schedule?.days[day] ?? null;
					const done = Boolean(completions?.[iso]);
					const isToday = todayDow === day;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: cn("rounded-xl", isToday && "border-primary/40"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "grid gap-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold",
									children: [WEEKDAYS_AR[day], isToday ? " · اليوم" : ""]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: plan ? rangeLabel(plan.fromSurah, plan.toSurah, plan.fromAyah, plan.toAyah) : "بدون مقدار"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "icon",
										variant: done ? "default" : "outline",
										className: "size-10",
										onClick: () => toggleCompletion(profile.id, iso),
										"aria-label": done ? "إلغاء الإنجاز" : "تعليم كمنجز",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "ghost",
										onClick: () => {
											setEditing(day);
											setDraft(plan ?? emptyPlan());
										},
										children: "تعديل"
									})]
								})]
							}), editing === day ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 rounded-xl bg-muted/70 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurahPicker, {
											label: "من سورة",
											value: draft.fromSurah,
											onChange: (id) => {
												const s = SURAH_BY_ID[id];
												setDraft((d) => ({
													...d,
													fromSurah: id,
													fromAyah: 1,
													toSurah: d.toSurah < id ? id : d.toSurah,
													toAyah: s?.ayahs ?? d.toAyah
												}));
											}
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurahPicker, {
											label: "إلى سورة",
											value: draft.toSurah,
											onChange: (id) => {
												const s = SURAH_BY_ID[id];
												setDraft((d) => ({
													...d,
													toSurah: id,
													toAyah: s?.ayahs ?? 1
												}));
											}
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "من آية" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 1,
												value: draft.fromAyah,
												onChange: (e) => setDraft((d) => ({
													...d,
													fromAyah: clampAyah(d.fromSurah, Number(e.target.value) || 1)
												}))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "إلى آية" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 1,
												value: draft.toAyah,
												onChange: (e) => setDraft((d) => ({
													...d,
													toAyah: clampAyah(d.toSurah, Number(e.target.value) || 1)
												}))
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "flex-1",
											onClick: () => {
												setDayPlan(profile.id, day, draft);
												setEditing(null);
											},
											children: "حفظ المقدار"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											onClick: () => {
												setDayPlan(profile.id, day, null);
												setEditing(null);
											},
											children: "مسح"
										})]
									})
								]
							}) : null]
						})
					}, day);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "الجمعة والسبت"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "أيام راحة في جدول الحلقة. يمكنك التسميع متى شئت من قسم الحفظ أو الربط."
					})]
				})
			})
		]
	});
}
//#endregion
export { SchedulePage as component };
