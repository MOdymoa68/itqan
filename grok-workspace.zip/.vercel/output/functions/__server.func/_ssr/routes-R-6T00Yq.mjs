import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as sessionItqan, n as averageItqan, r as countByKind, t as Badge } from "./badge-FGECkbyy.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ArrowLeft, S as BookMarked, c as RefreshCw, f as Link2 } from "../_libs/lucide-react.mjs";
import { A as todayISO, C as cn, E as formatHijri, M as useItqanStore, O as rangeLabel, T as formatArDate, _ as STUDY_DAYS, b as WEEKDAYS_AR, d as SESSION_LABEL, g as CardContent, h as Card, j as useActiveProfile, k as startOfWeekSunday, m as Button, u as ERROR_LABEL, x as addDays } from "./router-B38-chNx.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-R-6T00Yq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-muted", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-primary transition-[width] duration-fast ease-smooth-out",
		style: { width: `${value ?? 0}%` }
	})
}));
Progress.displayName = Root.displayName;
function Home() {
	const profile = useActiveProfile();
	const sessions = useItqanStore((s) => profile ? s.sessions.filter((x) => x.profileId === profile.id) : []);
	const schedule = useItqanStore((s) => profile ? s.schedules[profile.id] : void 0);
	const completions = useItqanStore((s) => profile ? s.completions[profile.id] : void 0);
	const today = /* @__PURE__ */ new Date();
	const dow = today.getDay();
	const iso = todayISO(today);
	const plan = schedule?.days[dow] ?? null;
	const doneToday = Boolean(completions?.[iso]);
	const weekStart = startOfWeekSunday(today);
	const weekSessions = sessions.filter((s) => {
		const start = todayISO(weekStart);
		const end = todayISO(addDays(weekStart, 6));
		return s.date >= start && s.date <= end;
	});
	const weekItqan = averageItqan(weekSessions);
	const weekCounts = countByKind(weekSessions.flatMap((s) => s.errors));
	const recent = sessions.slice(0, 4);
	const studyDone = STUDY_DAYS.filter((d) => {
		const date = todayISO(addDays(weekStart, d));
		return Boolean(completions?.[date]);
	}).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: formatHijri(today)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-1 text-2xl font-semibold",
					children: ["سلامًا ", profile?.name]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [
						formatArDate(iso),
						" · ",
						WEEKDAYS_AR[dow]
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-muted-foreground",
						children: "مقرر اليوم"
					}), dow > 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-base font-medium",
						children: "راحة نهاية الأسبوع"
					}) : plan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-base font-medium",
						children: rangeLabel(plan.fromSurah, plan.toSurah, plan.fromAyah, plan.toAyah)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-base font-medium",
						children: "لم يُحدد مقدار بعد"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: doneToday ? "default" : "outline",
						children: doneToday ? "تم التسميع" : "بالانتظار"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/recite/$type",
							params: { type: "hifz" },
							children: "ابدأ التسميع"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/schedule",
							children: "الجدول"
						})
					})]
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-muted-foreground",
						children: "إتقان الأسبوع"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl text-primary tabular-nums",
						children: weekItqan == null ? "—" : `${weekItqan}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						className: "mt-3",
						value: weekItqan ?? 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: [studyDone, " من 5 أيام دراسية"]
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-muted-foreground",
						children: "أخطاء الأسبوع"
					}), [
						["stop", weekCounts.stop],
						["lahn", weekCounts.lahn],
						["note", weekCounts.note]
					].map(([k, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ERROR_LABEL[k] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums font-medium",
							children: n
						})]
					}, k))]
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "أقسام التسميع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeCard, {
							type: "hifz",
							icon: BookMarked,
							title: "حفظ جديد",
							hint: "سورة مقررة واحدة، مع تصحيح الكلمة حسب المصحف"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeCard, {
							type: "rabt",
							icon: Link2,
							title: "ربط",
							hint: "مدى من سورة إلى سورة أثناء الربط"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeCard, {
							type: "murajaa",
							icon: RefreshCw,
							title: "مراجعة",
							hint: "نفس آلية الربط لمواضع المراجعة"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "آخر الجلسات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/history",
						className: "text-xs font-medium text-primary",
						children: "السجل كامل"
					})]
				}), recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "py-8 text-center text-sm text-muted-foreground",
					children: "لا جلسات بعد. ابدأ تسميعًا من الأزرار أعلاه."
				}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: recent.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "flex items-center justify-between gap-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-medium",
									children: [
										SESSION_LABEL[s.type],
										" ·",
										" ",
										rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: formatArDate(s.date)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-display text-2xl text-primary tabular-nums",
								children: [sessionItqan(s), "%"]
							})]
						})
					}) }, s.id))
				})]
			})
		]
	});
}
function TypeCard({ type, icon: Icon, title, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/recite/$type",
		params: { type },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "rounded-xl transition-colors hover:bg-muted/60",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex items-center gap-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-lg bg-secondary text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-semibold",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: hint
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4 text-muted-foreground" })
				]
			})
		})
	});
}
//#endregion
export { Home as component };
