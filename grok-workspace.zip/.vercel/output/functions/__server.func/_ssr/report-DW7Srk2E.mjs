import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as sessionItqan, n as averageItqan, r as countByKind, t as Badge } from "./badge-FGECkbyy.mjs";
import { h as Download, l as Printer } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as todayISO, M as useItqanStore, O as rangeLabel, T as formatArDate, _ as STUDY_DAYS, b as WEEKDAYS_AR, c as CIRCLE_NAME, d as SESSION_LABEL, g as CardContent, h as Card, j as useActiveProfile, k as startOfWeekSunday, m as Button, s as APP_NAME$1, u as ERROR_LABEL, x as addDays } from "./router-B38-chNx.mjs";
import { n as repeatedWords, r as weekSessions, t as downloadWeeklyPng } from "./report-n5j0yf_o.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/report-DW7Srk2E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReportPage() {
	const profile = useActiveProfile();
	const sessions = useItqanStore((s) => profile ? s.sessions.filter((x) => x.profileId === profile.id) : []);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const weekStart = startOfWeekSunday();
	const week = weekSessions(sessions, weekStart);
	const counts = countByKind(week.flatMap((s) => s.errors));
	const avg = averageItqan(week);
	const weak = repeatedWords(week, 2).slice(0, 8);
	async function saveImage() {
		if (!profile) return;
		setBusy(true);
		try {
			await downloadWeeklyPng(profile, sessions);
			toast.success("حُفظت صورة التقرير");
		} catch {
			toast.error("تعذر إنشاء الصورة");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "تقرير الإنجاز"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "ملخص الأسبوع للمعلم أو للحفظ الشخصي. يمكن حفظه صورة أو طباعته PDF."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void saveImage(),
					disabled: busy || !profile,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "حفظ صورة"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => window.print(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "طباعة / PDF"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "print:border-0 print:shadow-none",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "grid gap-5 py-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "border-b border-border pb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl text-primary",
									children: APP_NAME$1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: CIRCLE_NAME
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm font-medium",
									children: profile?.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										formatArDate(todayISO(weekStart)),
										" — ",
										formatArDate(todayISO(addDays(weekStart, 4)))
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2 sm:grid-cols-5",
							children: [
								["الإتقان", avg == null ? "—" : `${avg}%`],
								["الجلسات", String(week.length)],
								[ERROR_LABEL.stop, String(counts.stop)],
								[ERROR_LABEL.lahn, String(counts.lahn)],
								[ERROR_LABEL.note, String(counts.note)]
							].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-muted/70 px-3 py-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl tabular-nums text-primary",
									children: value
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: label
								})]
							}, label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "الأيام الدراسية"
							}), STUDY_DAYS.map((d) => {
								const iso = todayISO(addDays(weekStart, d));
								const list = week.filter((s) => s.date === iso);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3 rounded-lg bg-muted/50 px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium",
										children: WEEKDAYS_AR[d]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-left text-sm text-muted-foreground",
										children: list.length === 0 ? "لم يُسمَّع" : list.map((s) => `${SESSION_LABEL[s.type]} · ${rangeLabel(s.fromSurah, s.toSurah, s.fromAyah, s.toAyah)} · ${sessionItqan(s)}%`).join(" · ")
									})]
								}, d);
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "كلمات متكررة هذا الأسبوع"
							}), weak.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "لا تكرار يُذكر."
							}) : weak.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xl",
									children: w.word
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "stop",
									children: [w.count, "×"]
								})]
							}, w.word))]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { ReportPage as component };
